package com.att.idp.logging;

public enum LogLevel {	
	OFF,
	INFO,
	DEBUG;
	
	public boolean isInfoEnabled() {
		return this.ordinal() >= INFO.ordinal();
	}
	
	public boolean isDebugEnabled() {
		return this.ordinal() >= DEBUG.ordinal();
	}
}
