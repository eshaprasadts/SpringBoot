package com.att.idp.logging.client;

import java.io.IOException;

public final class LogFormatter {
	
	 static final String NOTIFICATION_PREFIX = "* ";

	static final String REQUEST_PREFIX = ">> ";

	 static final String RESPONSE_PREFIX = "<< ";
	
	public LogFormatter() {
	}

	public  static void outboundRequestPrefix(StringBuilder strBuffer) {
		strBuffer.append(NOTIFICATION_PREFIX).append("Client out-bound request").append('\n');
	}
	
	public  static StringBuilder outboundRequestPrefix() {
		return null;
		
	}

	
	
	/**
	 * @param strBuffer
	 * @param entity
	 * @throws IOException
	 */
	public  static void printEntity(StringBuilder strBuffer, byte[] entity) throws IOException {
		if (entity.length == 0)
			return;
		strBuffer.append(new String(entity)).append("\n");
	}
	
	
	/**
	 * Prints Response Line
	 * 
	 * @param strBuffer
	 * @param response
	 */
	public  static void printResponseLine(StringBuilder strBuffer, String appendStr1) {
		prefixId(strBuffer).append(NOTIFICATION_PREFIX).append("Client out-bound response").append('\n');
		prefixId(strBuffer).append(RESPONSE_PREFIX).append(appendStr1).append('\n');
	}

	/**
	 * @param stringBuilder
	 * @return
	 */
	public  static StringBuilder prefixId(StringBuilder StringBuilder) {
		return StringBuilder;
	}

	/**
	 * @param strBuffer
	 * @param request
	 */
	public  static void printRequestLine(StringBuilder strBuffer, String appendStr1,String appendStr2) {
		prefixId(strBuffer).append(NOTIFICATION_PREFIX).append("Client out-bound request").append('\n');
		prefixId(strBuffer).append(REQUEST_PREFIX).append(appendStr1).append(" ")
				.append(appendStr2).append('\n');
	}


	
}
