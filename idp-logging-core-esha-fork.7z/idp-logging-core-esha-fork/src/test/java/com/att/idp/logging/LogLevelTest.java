package com.att.idp.logging;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.att.idp.logging.LogLevel;

public class LogLevelTest {
	
	@Test
	public void testLogEnabled() {
		LogLevel toBeTested = LogLevel.DEBUG;
		
		assertTrue(toBeTested.isInfoEnabled());
		assertTrue(toBeTested.isDebugEnabled());
	}
	
	@Test
	public void testLogDisabled() {
		LogLevel toBeTested = LogLevel.INFO;		

		assertTrue(toBeTested.isInfoEnabled());
		assertFalse(toBeTested.isDebugEnabled());
	}

}
