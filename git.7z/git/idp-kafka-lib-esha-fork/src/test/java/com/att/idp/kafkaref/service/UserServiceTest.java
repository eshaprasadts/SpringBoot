package com.att.idp.kafkaref.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.idp.kafkaref.config.KafkaProducerConfig;
import com.att.idp.kafkaref.eventhandler.producer.EventProducer;
import com.att.idp.kafkaref.model.User;
import com.att.idp.kafkaref.repository.UserRepositoryImpl;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes= {UserServiceImpl.class, UserRepositoryImpl.class, EventProducer.class, KafkaProducerConfig.class})
public class UserServiceTest {
	
	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	@Autowired
	UserService userService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

/*	@Test
	public void testGetUser() throws Exception {
		Response response = userResource.getUser("123");
		assertEquals("123", ((Resource<User>)response.getEntity()).getContent().getId());
	}
*/	
	@Test
	public void testCreateUser() throws Exception {		
		User user = new User();
		user.setName("john");
		User created = userService.createUser(user);
		assertNotNull(created);
		assertNotNull(created.getId());
		assertEquals("john", created.getName());
	}
	
	@Test
	public void testGetUser() throws Exception {		
		User user = new User();
		user.setName("Doe");
		User created = userService.createUser(user);
		
		User read = userService.getUser(created.getId());
		assertNotNull(read);
		assertEquals(created, read);
	}
	
	@Test
	public void testUpdateUser() throws Exception {		
		User updated = userService.updateUser(null);
		
		assertEquals(null, updated);
	}

	
}
