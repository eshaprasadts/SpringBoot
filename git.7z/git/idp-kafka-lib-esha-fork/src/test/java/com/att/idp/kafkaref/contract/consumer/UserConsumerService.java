package com.att.idp.kafkaref.contract.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/*Used for the PACT Contract verification only*/
public class UserConsumerService {

	private String url;
	private RestTemplate restTemplate;

	@Autowired
	public UserConsumerService(@Value("${producer}") String url) {
		this.url = url;
		this.restTemplate = new RestTemplate();
	}

	/*
	 * The API is called against the mock server and the response is returned.
	 */
	public int createUser() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Basic bTE5MzE2QGlkc2UuYXR0LmNvbTppZHBmb3JtMTc=");

		HttpEntity<String> entity = new HttpEntity<>("{\"id\":\"123\",\"name\":\"dummy\"}", headers);
		ResponseEntity<String> response = restTemplate.exchange(url + "/msapi/v1/users", HttpMethod.POST, entity, String.class);
		return response.getStatusCode().value();
	}
}