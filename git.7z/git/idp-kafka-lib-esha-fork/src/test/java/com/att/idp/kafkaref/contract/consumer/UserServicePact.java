package com.att.idp.kafkaref.contract.consumer;

import static junit.framework.TestCase.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Rule;
import org.junit.Test;

import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRule;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.PactFragment;
import au.com.dius.pact.model.PactSpecVersion;
/*
 * This class defines the pact between the consumer and producer.
 * For each provider, similar class should be written.
 * This class generates the pact file and uploaded to broker url as part of jenkins pipeline.
 */
public class UserServicePact {

	/*In below example idp-kafka-lib is the provide name, 
	 * work with provider ms team to find the exact name they use.
	 * The name must match exactly and is case sensitive.
	 */
	@Rule
	public PactProviderRule rule = new PactProviderRule("idp-kafka-lib", PactSpecVersion.V3, this);

	/*
	 * This method defines the contract between the consumer and provider.
	 * Multiple API for the same provider must be defined in the same method with different uponReceiving() condtions.
	 * Provide the Consumer name which is usually consumer microservice name and the provide name.
	 */
	@Pact(provider = "idp-kafka-lib", consumer = "idp-kafka-lib")
	public PactFragment createFragment(PactDslWithProvider builder) {

		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", "Basic bTE5MzE2QGlkc2UuYXR0LmNvbTppZHBmb3JtMTc=");

		return builder.given("default")  //state of the provider before executing the pact
				.uponReceiving("create a user")  // user friendly name for the service api
				.method("POST") // API method type
				.headers(headers) // input headers
				.body("{\"id\":\"123\",\"name\":\"dummy\"}") //request body
				.path("/msapi/v1/users")  //API URL
				.willRespondWith() // the expected response
				.status(201)
				.toFragment();
	}
	
	/*
	 * Self Pact verification test case. It validates the pact contract create above by running against a mock server.
	 */
	@Test
	@PactVerification(value = "idp-kafka-lib", fragment = "createFragment")
	public void runTest() {
    	UserConsumerService userservice = new UserConsumerService(rule.getConfig().url());
    	int status = userservice.createUser();
    	assertEquals(201, status);
	}

}