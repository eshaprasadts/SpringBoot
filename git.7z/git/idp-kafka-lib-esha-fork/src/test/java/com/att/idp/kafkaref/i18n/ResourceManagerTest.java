package com.att.idp.kafkaref.i18n;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Locale;

import org.junit.Test;

import com.att.idp.kafkaref.message.TestMessages;




public class ResourceManagerTest {

    /**
     * A simple message skeleton to test the resource manager
     */
    public static final String testSkeleton =
        "Prior configuration has been cleared";

   
    /**
     * Make sure that the asList method works correctly
     */
    @Test
    public void testAsList() {
        assertEquals("[A,B,C,D]", ResourceManager.asList("A", "B", "C", "D"));
        assertEquals("[]", ResourceManager.asList());
    }

    /**
     * Create an exception and then test that we can format it
     */
    @Test
    public void testFormatException() {
        try {
            try {
                throw new NullPointerException("Dummy Exception");
            } catch (NullPointerException e) {
                throw new IllegalArgumentException("Dummy Exception", e);
            }
        } catch (IllegalArgumentException e1) {
            String msg = ResourceManager.format(e1);
            assertNotNull(msg);
            // System.out.println(msg);
            assertTrue(msg.startsWith("Exception in class java.lang.IllegalArgumentException: Dummy Exception"));
        }
    }

    @Test
    public void testFormatException_1() {
    	Locale locale = new Locale("en","US");
    	try {
            try {
                throw new NullPointerException("Dummy Exception");
            } catch (NullPointerException e) {
                throw new IllegalArgumentException("Dummy Exception", e);
            }
        } catch (IllegalArgumentException e1) {
        String msg = ResourceManager.format(locale,TestMessages.ERROR_USER_NOT_FOUND,"DP5252");
        assertNotNull(msg);
        //System.out.println(msg);
        assertTrue(msg.startsWith("APP30003E  User DP5252 not found"));
        }  
    }

    @Test
    public void testFormatException_2() {
    	Locale locale = new Locale("en","US");
    	
        String msg = ResourceManager.format(locale,TestMessages.ERROR_USER_NOT_FOUND,"DP5252");
        assertNotNull(msg);
        //System.out.println(msg);
        assertTrue(msg.startsWith("APP30003E  User DP5252 not found"));
        
    }


    @Test
    public void testFormatException_3() {
    	try {
            try {
                throw new NullPointerException("Dummy Exception");
            } catch (NullPointerException e) {
                throw new IllegalArgumentException("Dummy Exception", e);
            }
        } catch (IllegalArgumentException e1) {
        String msg = ResourceManager.format(e1,"Test Message");
        assertNotNull(msg);
        assertTrue(msg.startsWith("Exception in class java.lang.IllegalArgumentException"));
        }  
    }

    @Test
    public void testFormatException_4() {
    	try {
            try {
                throw new NullPointerException("Dummy Exception");
            } catch (NullPointerException e) {
                throw new IllegalArgumentException("Dummy Exception", e);
            }
        } catch (IllegalArgumentException e1) {
        String msg = ResourceManager.format(TestMessages.ERROR_USER_NOT_FOUND,e1,"DP5252");
        assertNotNull(msg);
        //System.out.println(msg);
        assertTrue(msg.startsWith("APP30003E  User DP5252 not found"));
        }  
    }

    @Test
    public void testFormatException_5() {
    	Locale locale = new Locale("en","US");
    	try {
            try {
                throw new NullPointerException("Dummy Exception");
            } catch (NullPointerException e) {
                throw new IllegalArgumentException("Dummy Exception", e);
            }
        } catch (IllegalArgumentException e1) {
        String msg = ResourceManager.format(locale,TestMessages.ERROR_USER_NOT_FOUND,e1,"DP5252");
        assertNotNull(msg);
        //System.out.println(msg);
        assertTrue(msg.startsWith("APP30003E  User DP5252 not found"));
        }  
    }

    /**
     * Test that we can format a message
     */
    @Test
    public void testFormatMessage() {
    	String msg  = "APP10001I Application initialization started at {0}";
        String pattern = msg.replaceAll("\\{[0-9]+\\}", "%s");
        String[] args = new String[] { "9/30/2015" };
        String expectedResults = String.format(pattern, (Object[]) args); 

        String resource = ResourceManager.format(TestMessages.MESSAGE_CONFIGURATION_STARTED, args);
        assertNotNull(resource);
        assertEquals(expectedResults, resource);
    }
    
    /**
     * Test that we can format a message
     */
    @Test
    public void testFormatMessage_1() {
        String[] args = new String[] { "DP5252" };

        String resource = ResourceManager.format(TestMessages.ERROR_USER_NOT_FOUND, args);
        assertNotNull(resource);
        //System.out.println(resource);
        assertTrue(resource.startsWith("APP30003E  User DP5252 not found"));
    }

    /**
     * Test that we can format a message
     */
    @Test
    public void testFormatMessage_2() {

        String resource = ResourceManager.format(TestMessages.TEST_MESSAGE);
        assertNotNull(resource);
        //System.out.println(resource);
        assertTrue(resource.startsWith("SECOND Third"));
    }


    /**
     * Test the ability to lookup a resource
     */
    @Test
    public void testGetResource() {
        String resource = ResourceManager.getMessage(TestMessages.MESSAGE_CONFIGURATION_CLEARED.name());
        assertNotNull(resource);
        assertEquals(testSkeleton, resource);
    }

    /**
     * Test the ability to lookup a description
     */
    @Test
    public void testGetDescription() {
    	Locale locale = new Locale("en","US");
        String desc = ResourceManager.getDescription(locale,TestMessages.TEST_MESSAGE);
        assertNotNull(desc);
        //System.out.println(desc);
        assertEquals("Fifth", desc);
        locale=null;
        desc = ResourceManager.getDescription(locale,TestMessages.TEST_MESSAGE);
        //System.out.println(desc);
        assertTrue(desc.startsWith("EELF9998E Resource id [TEST_MESSAGE] cannot be formatted"));
    }

    /**
     * Test the ability to lookup a description
     */
    @Test
    public void testGetDescription_1() {
        String desc = ResourceManager.getDescription(TestMessages.TEST_MESSAGE);
        assertNotNull(desc);
        //System.out.println(desc);
        assertEquals("Fifth", desc);
    }

    /**
     * Test the ability to lookup a resolution
     */
    @Test
    public void testGetResolution() {
    	Locale locale = new Locale("en","US");
        String resolution = ResourceManager.getResolution(locale,TestMessages.TEST_MESSAGE);
        assertNotNull(resolution);
        //System.out.println(resolution);
        assertEquals("Fourth", resolution);
        locale=null;
        resolution = ResourceManager.getResolution(locale,TestMessages.TEST_MESSAGE);
        //System.out.println(resolution);
        assertTrue(resolution.startsWith("EELF9998E Resource id [TEST_MESSAGE] cannot be formatted"));

    }

    /**
     * Test the ability to lookup a resolution
     */
    @Test
    public void testGetResolution_1() {
        String resolution = ResourceManager.getResolution(TestMessages.TEST_MESSAGE);
        assertNotNull(resolution);
        //System.out.println(resolution);
        assertEquals("Fourth", resolution);
    }

    /**
     * Test the ability to lookup a HTTPCode
     */
    @Test
    public void testGetHTTPCode() {
    	Locale locale = new Locale("en","US");
        int code = ResourceManager.getHttpCode(locale,TestMessages.TEST_MESSAGE);
        assertNotNull(code);
        //System.out.println(code);
        assertEquals(100, code);
        locale=null;
        code = ResourceManager.getHttpCode(locale,TestMessages.TEST_MESSAGE);
        //System.out.println(code);
        assertEquals(500,code);

    }

    @Test
    public void testGetHTTPCode_1() {
        int code = ResourceManager.getHttpCode(TestMessages.TEST_MESSAGE);
        assertNotNull(code);
        //System.out.println(code);
        assertEquals(100, code);
    }


    /**
     * Test the ability to lookup a Identified
     */
    @Test
    public void testGetIdentifier() {
    	Locale locale = new Locale("en","US");
        String Id = ResourceManager.getIdentifier(locale,TestMessages.TEST_MESSAGE);
        assertNotNull(Id);
        //System.out.println(Id);
        assertEquals("Second", Id);
        locale=null;
        Id = ResourceManager.getIdentifier(locale,TestMessages.TEST_MESSAGE);
        //System.out.println(Id);
        assertTrue(Id.startsWith("EELF9998E Resource id [TEST_MESSAGE] cannot be formatted"));

    }

    /**
     * This method is used to -ve test loadResolutionBundle class 
     */
    @Test
    public void testLoadResolutionBundle() {
        ResourceManager.loadResolutionBundle("UnknownResource");
        assertTrue(true);
        ResourceManager.loadResolutionBundle(TestMessages.TEST_MESSAGE.toString());
    }

    /**
     * This method is used to test that attempts to load a bad or unknown resource generate the appropriate response...
     */
    @Test
    public void testLoadBadResource() {
        String message = ResourceManager.getMessage("UnknownResource");
        assertTrue(message
            .contains("Resource id [UnknownResource] cannot be formatted - no resource with that id exists!"));
        // System.out.println(message);
        Locale locale=null;
        message = ResourceManager.getMessage(locale,TestMessages.TEST_MESSAGE.toString());
        //System.out.println(message);
        assertTrue(message.startsWith("EELF9998E Resource id [TEST_MESSAGE] cannot be formatted"));

    }

    /**
     * Test that if we attempt to load a bad resource bundle, the resource manager fails to load it, generates a stderr
     * message, and ignores it.
     */
    @Test
    public void testLoadBadResourceBundle() {
        String resource = ResourceManager.getMessage(TestMessages.MESSAGE_CONFIGURATION_CLEARED.name());
        assertNotNull(resource);
        assertEquals(testSkeleton, resource);
    }

    /**
     * See if the bundle was loaded. It should be the default bundle (en_US)
     */
    @Test
    public void testLoadEnglishUSBundle() {
        String message = ResourceManager.getMessage(TestMessages.MESSAGE_CONFIGURATION_CLEARED.name());
        assertEquals(testSkeleton, message);
        message = ResourceManager.getMessage(TestMessages.TEST_MESSAGE);
        assertEquals("Third",message);
        message = ResourceManager.getMessage(TestMessages.ERROR_USER_NOT_FOUND,"DP5252");
        assertTrue(message.startsWith("APP30003E  User DP5252 not found"));
    }

   
}