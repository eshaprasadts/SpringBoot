package com.att.idp.kafkaref.representation;

import static org.junit.Assert.assertEquals;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.idp.kafkaref.representation.CollectionLinks;

public class CollectionLinksTest {

	@Autowired
	public CollectionLinks links;
	@Before
	public void setUp() throws Exception {

		links = new CollectionLinks("First");
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
    public void testAllCollectionLinks() {

		links.setFirst("First");
		links.setPrev("prev");
		links.setNext("next");
		links.setLast("last");

		// default test
		assertEquals("First",links.getFirst().toString());
		assertEquals("prev",links.getPrev().toString());
		assertEquals("next",links.getNext().toString());
		assertEquals("last",links.getLast().toString());

	}
}