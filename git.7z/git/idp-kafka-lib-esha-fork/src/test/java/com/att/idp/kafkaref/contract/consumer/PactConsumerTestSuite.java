package com.att.idp.kafkaref.contract.consumer;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.att.idp.kafkaref.contract.consumer.UserServicePact;

/*
 * All the consumer pact classes must be registered with-in this suite,
 * otherwise that pact file is not generated
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({ 
	UserServicePact.class
})
public class PactConsumerTestSuite {
}