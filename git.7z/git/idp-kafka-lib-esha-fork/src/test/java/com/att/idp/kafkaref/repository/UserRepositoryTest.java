package com.att.idp.kafkaref.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.idp.kafkaref.config.KafkaProducerConfig;
import com.att.idp.kafkaref.eventhandler.producer.EventProducer;
import com.att.idp.kafkaref.model.User;
import com.att.idp.kafkaref.repository.UserRepositoryImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes= {UserRepositoryImpl.class,EventProducer.class, KafkaProducerConfig.class})
public class UserRepositoryTest {

	@Autowired
	UserRepository repository;
	
	@Test
	public void testCreateUser() throws Exception {
		User user = new User("dp5252");
		User saved = repository.createUser(user);
		
		assertEquals(user.getId(), saved.getId());
		assertEquals(user.getName(), user.getName());
	}
	
	@Test
	public void testGetUser() throws Exception {
		User user = new User("12345");
		user.setName("Doe");
		repository.createUser(user);
		
		User retrieved = repository.getUser(user.getId());
		
		assertEquals(user.getId(), retrieved.getId());
		assertEquals(user.getName(), retrieved.getName());
		assertTrue(repository instanceof UserRepositoryImpl);
	}
}