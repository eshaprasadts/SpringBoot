package com.att.idp.kafkaref.representation;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.att.idp.kafkaref.model.User;

public class ResourceCollectionTest {

	public ResourceCollection<User> collection;
	
	public CollectionLinks links;
	
	public List<User> users;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before
	public void setUp() throws Exception {
		users= new ArrayList<>();
		
		User user = new User("17951");
		users.add(user);
		collection = new ResourceCollection(users);
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testGetCollection() throws Exception {

		
		List<User> result;

		// default test
		result = collection.getCollection();
		assertEquals(users,result);
	}
	
	@Test
	public void testSetLinks() throws Exception {

		links = new CollectionLinks("First");
		links.setFirst("First");
		links.setPrev("prev");
		links.setNext("next");
		links.setLast("last");

		// default test
		collection.setLinks(links);
		assertEquals(links.getFirst().toString(),collection.getLinks().getFirst().toString());
		assertEquals(links.getPrev().toString(),collection.getLinks().getPrev().toString());
		assertEquals(links.getNext().toString(),collection.getLinks().getNext().toString());
		assertEquals(links.getLast().toString(),collection.getLinks().getLast().toString());
	}


	@Test
	public void testGetPagination() throws Exception {
		
		collection.setPagination(new Pagination(1,1,11));
		Pagination result= collection.getPagination();
		assertEquals(1,result.getPageNumber());
		assertEquals(1,result.getPageSize());
		assertEquals(11,result.getTotalCount());
	}

	@Test
	public void testGetLinks() throws Exception {
	
		CollectionLinks result;

		// default test
		result=collection.getLinks();
		assertEquals(links,result);
	}



	/**
	 *
	 * @see com.att.idp.kafkaref.representation.Pagination#Pagination(int,int,long)
	 */
	@Test
	public void testPagination() {
		Pagination pagination = new Pagination(1,1,11);
		assertEquals(1,pagination.getPageNumber());
		assertEquals(1,pagination.getPageSize());
		assertEquals(11,pagination.getTotalCount());
	}
	
	
}