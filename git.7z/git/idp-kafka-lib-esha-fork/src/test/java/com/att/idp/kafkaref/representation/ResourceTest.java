package com.att.idp.kafkaref.representation;

import static org.junit.Assert.assertEquals;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.idp.kafkaref.model.User;
import com.att.idp.kafkaref.representation.Links;
import com.att.idp.kafkaref.representation.Resource;


public class ResourceTest {

	@SuppressWarnings("rawtypes")
	@Autowired
	Resource resource;
	
	@Autowired
	public Links links;
	
	@Autowired
	public User user;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Before
	public void setUp() throws Exception {
		
		user= new User("17951");
		links = new Links("Test");
		resource = new Resource(user);
		resource.setLinks(links);
	}

	@After
	public void tearDown() throws Exception {

	}



	@Test
	public void testGetContent() throws Exception {
		User result;

		// default test
		result = (User) resource.getContent();
		assertEquals(user.getId(),result.getId());
	}

	@Test
	public void testGetLinks() throws Exception {
		Links result;

		// default test
		result = resource.getLinks();
		assertEquals(links.getSelf(),result.getSelf());
	}

	@Test
	public void testSetLinks() throws Exception {
		Links result;
		links = new Links("Msg");
		resource.setLinks(links);
		// default test
		result = resource.getLinks();
		assertEquals(links.getSelf(),result.getSelf());
		
	}
}