package com.att.idp.kafkaref.representation;

import static org.junit.Assert.assertEquals;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.idp.kafkaref.representation.Links;


public class LinksTest {

	@Autowired
	Links links;
	@Before
	public void setUp() throws Exception {
		links = new Links("Test");
	}

	@After
	public void tearDown() throws Exception {

	}


	@Test
	public void testGetSelf() throws Exception {

		String result;

		// default test

		result = links.getSelf();
		assertEquals("Test",result);
	}

}