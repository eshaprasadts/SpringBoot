/**
 * Classes for the component testing
 *
 */
package com.att.idp.kafkaref.component;