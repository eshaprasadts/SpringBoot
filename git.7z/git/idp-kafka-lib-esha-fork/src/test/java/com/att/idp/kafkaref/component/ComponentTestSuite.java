package com.att.idp.kafkaref.component;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/*
 * All the component test classes must be registered in this suite class,
 * otherwise that component test class will be ignored.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
	UserResourceCompTest.class
})
public class ComponentTestSuite {
}