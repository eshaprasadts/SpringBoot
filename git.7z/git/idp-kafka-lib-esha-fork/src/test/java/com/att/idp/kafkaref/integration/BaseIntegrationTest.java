package com.att.idp.kafkaref.integration;

import org.junit.Before;

import com.att.ajsc.common.utility.SystemPropertiesLoader;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class BaseIntegrationTest {
	
	static {
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	@Before
	public void setUp() throws Exception {
		String baseURI = System.getProperty("BASE_URL");
		RestAssured.baseURI = baseURI + "/msapi";
	}
	
	protected RequestSpecification givenBaseSpec() {
		return 
				RestAssured.given()
					.accept(ContentType.JSON)
					.contentType(ContentType.JSON)
					.header("Authorization", "Basic bTE5MzE2QGlkc2UuYXR0LmNvbTppZHBmb3JtMTc=");
	}
	
}
