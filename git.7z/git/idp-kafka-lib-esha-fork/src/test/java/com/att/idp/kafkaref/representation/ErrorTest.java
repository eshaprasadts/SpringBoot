package com.att.idp.kafkaref.representation;

import static org.junit.Assert.assertEquals;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.idp.kafkaref.exception.ServiceError;
import com.att.idp.kafkaref.representation.Error;
import com.att.idp.kafkaref.representation.Links;


public class ErrorTest {

	@Autowired
	public Error error;

	@Autowired
	public Links links;

	@Before
	public void setUp() throws Exception {
		error = new Error(new ServiceError("100", "TEST"));
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testGetError() throws Exception {
		ServiceError result;

		// default test
		result = error.getError();
		assertEquals(error.getError(),result);
	}


	@Test
	public void testSetLinks() throws Exception {
		links = new Links("Test");
		error.setLinks(links);
		testGetLinks();
	}
	
	@Test
	public void testGetLinks() throws Exception {
		Links result;
		links = new Links("Test");
		error.setLinks(links);
		result = error.getLinks();
		assertEquals("Test",result.getSelf());
	}

}