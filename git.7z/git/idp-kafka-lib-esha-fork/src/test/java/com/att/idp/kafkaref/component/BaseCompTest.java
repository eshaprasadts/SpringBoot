package com.att.idp.kafkaref.component;

import java.net.InetAddress;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class BaseCompTest {
	
	@Value("${server.contextPath}")
    private String contextPath;

	@LocalServerPort
	protected int randomServerPort;

	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	@Before
	public void setUp() throws Exception {
		RestAssured.baseURI = "http://" + InetAddress.getLocalHost().getHostName() + ":" + randomServerPort + contextPath;
	}

	protected RequestSpecification givenBaseSpec() {
		return 
				RestAssured.given()
					.accept(ContentType.JSON)
					.contentType(ContentType.JSON)
					.header("Authorization", "Basic bTE5MzE2QGlkc2UuYXR0LmNvbTppZHBmb3JtMTc=");
	}
}
