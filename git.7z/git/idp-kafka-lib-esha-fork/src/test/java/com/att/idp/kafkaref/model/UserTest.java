package com.att.idp.kafkaref.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;


public class UserTest {

	@Autowired
	public User user;
	@Before
	public void setUp() throws Exception {

		user = new User("DP5252");
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testEquals() throws Exception {
	
		Object obj = null;
		boolean result;

		// test 1
		obj = user; 		// this = obj
		result = user.equals(obj);
		assertEquals(true, result);

		obj = null;  		// obj=null
		result = user.equals(obj);
		assertEquals(false,result);

		obj=new ArrayList<Object>();  // Class != obj.class
		result = user.equals(obj);
		assertEquals(false, result);

		user.setId(null);
		obj=new User("17951","David");	// other.id !=null
		result = user.equals(obj);
		assertEquals(false, result);

		user.setId(null);
		obj=new User(null,"David");	// other.id !=null
		result = user.equals(obj);
		assertEquals(false, result);

		obj=new User("17951","David");
		user.setId("17954");	// id.equals(other.id)
		result = user.equals(obj);
		assertEquals(false, result);
		
		user.setId("17951");
		user.setName(null); 	// Other.name !=null
		result = user.equals(obj);
		assertEquals(false, result);
		
		obj=new User("17951",null);
		result = user.equals(obj);
		assertEquals(true, result);
		
		obj=new User("17951","David");
		user.setId("17951");		
		user.setName("Doss");	// name.equals(other.name)
		result = user.equals(obj);
		assertEquals(false, result);
		
		user.setName("David");
		result = user.equals(obj);
		assertEquals(true, result);
		//System.out.println(result);
	}

	@Test
	public void testToString() throws Exception {

		String result;

		// default test
		user.setName("David");
		result = user.toString();
		assertEquals("{id:DP5252, name=David]",result);
	}

	@Test
	public void testHashcode() throws Exception {

		int result;

		// default test
		user.setName("David");
		result = user.hashCode();
		assertEquals(-1667631537,result);
		user.setId(null);
		result = user.hashCode();
		assertEquals(65806869,result);
		user.setName(null);
		result = user.hashCode();
		assertEquals(961,result);
	}

	

}