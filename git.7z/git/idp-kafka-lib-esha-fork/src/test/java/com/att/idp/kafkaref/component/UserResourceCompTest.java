package com.att.idp.kafkaref.component;

import org.junit.Test;

import com.att.idp.kafkaref.model.User;

public class UserResourceCompTest extends BaseCompTest {
 
		private String uri ="/v1/users";
		
		@Test
		public void testCreateUser_success() {
			
			User user = new User("12345");
			user.setName("Doe");
			
			givenBaseSpec()
				.body(user)
				.when()
					.post(uri)
					.then()
						.statusCode(201);
		}
		
		@Test
		public void testCreateUser_failure() {
			
			User user = new User("12345");
			
			givenBaseSpec()
				.body(user)
				.when()
					.post(uri)
					.then()
						.statusCode(400);

			givenBaseSpec()
			.body("")
			.when()
				.post(uri)
				.then()
					.statusCode(400);			
		}
		
		@Test
		public void testGetUser_success() {
			
			User user = new User("22222");
			user.setName("Doe");
			
			givenBaseSpec()
				.body(user)
				.when()
					.post(uri)
					.then()
					.statusCode(201);

			givenBaseSpec()
			.when()
				.get(uri + "/22222")
				.then()
					.statusCode(200);
		}
		
	   
	}