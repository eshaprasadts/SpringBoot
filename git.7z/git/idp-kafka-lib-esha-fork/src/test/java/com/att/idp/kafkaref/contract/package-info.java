/**
 * Classes for the pact testing
 *
 */
package com.att.idp.kafkaref.contract;