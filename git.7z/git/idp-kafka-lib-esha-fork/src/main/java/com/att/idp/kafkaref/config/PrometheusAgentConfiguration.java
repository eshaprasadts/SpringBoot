package com.att.idp.kafkaref.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.ajsc.introscope.interceptors.IntroscopePostInterceptor;
import com.att.ajsc.introscope.interceptors.IntroscopePreInterceptor;

/**
 * @author as860a
 *
 */
@Configuration
public class PrometheusAgentConfiguration {

	/**
     * Register the following interceptor based on the archetype
     * sdk-java-restlet-archetype--- IntroscopeRestletPreInterceptor
     * sdk-java-camel-archetype--- IntroscopeCamelPreInterceptor
     * sdk-java-jersey-archetype--- IntroscopePreInterceptor
     * 
     * @return preInterceptor
     */
	@Bean
	public IntroscopePreInterceptor preInterceptor(){
		return new IntroscopePreInterceptor();
	}
	
	/**
     * Register the following interceptor based on the archetype
     * sdk-java-restlet-archetype--- IntroscopeRestletPostInterceptor
     * sdk-java-camel-archetype--- IntroscopeCamelPostInterceptor
     * sdk-java-jersey-archetype--- IntroscopePostInterceptor
     * 
     * @return postInterceptor
     */
	@Bean
	public IntroscopePostInterceptor postInterceptor(){
		return new IntroscopePostInterceptor();
	}
	
}
