package com.att.idp.kafkaref.representation;

import java.io.Serializable;

import com.att.idp.kafkaref.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The POJO representation of the error that can be communicated with client apps.
 * e.g. It does not have technical information like stack trace/call tree.
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Error implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
	/**
	 * Hypermedia link to get more information about this Error 
	 * 	such as causes & solutions.
	 */
	private Links links;
	
	private ServiceError error;
	
	/**
	 * This is public constructor which takes ServiceError instance as input
	 *  
	 * @param error ServiceError object instance
	 */

	public Error(ServiceError error) {
		super();
		setError(error);
	}	
	
	@SuppressWarnings("unused")
	private void setError(ServiceError error) {
		this.error = error;
	}
	
	public ServiceError getError() {
		return error;
	}

	public Links getLinks() {
		return links;
	}

	public void setLinks(Links links) {
		this.links = links;
	}			
}


