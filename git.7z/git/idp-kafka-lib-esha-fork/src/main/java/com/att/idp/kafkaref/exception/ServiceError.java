package com.att.idp.kafkaref.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.att.idp.kafkaref.i18n.ResolvableErrorEnum;
import com.att.idp.kafkaref.i18n.ResourceManager;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The POJO representation of the error that can be communicated with client apps.
 * e.g. It does not have technical information like stack trace/call tree.
 *
 * Below is the serialized representation in Json format.
 *
 *  {
 *       "errorId" : "",
 *       "message" : "",
 *       "details" : [
 *           {
 *               "code":"",
 *               "message":""
 *           }
 *       ]
 *  }
 *  
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceError implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * errorId at the request/message level.
	 */
	private String errorId;
	
	/**
	 * error message at the request/message level.
	 */	
	private String message;
	/**
	 * Additional details of the error. e.g. attribute level validation errors
	 */
	private List<Error> details;
	
	/**
	 * Constructor for Service Error
	 * 
	 * @param errorId Error Code
	 * 
	 * @param message Error description
	 */
	public ServiceError(String errorId, String message) {
		super();
		setErrorId(errorId);
		setMessage(message);
	}

	@SuppressWarnings("unused")
	private void setErrorId(String errorId) {
		this.errorId = errorId;
	}

	@SuppressWarnings("unused")
	private void setMessage(String message) {
		this.message = message;
	}

	@SuppressWarnings("unused")
	private void setDetails(List<Error> details) {
		this.details = details;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getErrorId() {
		return errorId;
	}

	public String getMessage() {
		return message;
	}

	public List<Error> getDetails() {
		return details;
	}

	void addDetail(Error error) {
		if(this.details == null) {
			this.details = new ArrayList<>();
		}
		this.details.add(error);
	}

	void addDetail(ResolvableErrorEnum detail, String... args) {
		String code = ResourceManager.getIdentifier(detail);
		String msg = ResourceManager.getMessage(detail, args);
		this.addDetail(new Error(code, msg));
	}
	
	/**
	 * Granular Code-Message pair to be used for Error details.
	 * e.g. Validation Error
	 *
	 */
	static class Error implements Serializable{	
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		private String code;
		private String message;

		public Error(String code, String message) {
			super();
			setCode(code);
			setMessage(message);
		}

		@SuppressWarnings("unused")
		private void setCode(String code) {
			this.code = code;
		}
		
		@SuppressWarnings("unused")
		private void setMessage(String message) {
			this.message = message;
		}

		public String getCode() {
			return code;
		}

		public String getMessage() {
			return message;
		}						
	}
}


