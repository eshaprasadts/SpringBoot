/**
 * Classes related to the string literals
 * 
 * ErrorMessages, LogMessages
 *
 */
package com.att.idp.kafkaref.message;