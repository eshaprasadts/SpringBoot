package com.att.idp.kafkaref.exception;

import com.att.idp.kafkaref.i18n.ResolvableErrorEnum;
import com.att.idp.kafkaref.i18n.ResourceManager;

/**
 * Unchecked Exception (child of RuntimeException) that can be thrown by application code.
 * This is similar to <code>WebApplicationException</code>, provided by JAX-RS for convenient use.
 * 
 * This custom exception is created to encapsulate the extra details 
 * (e.g. list of validation errors along with general invalid input error)
 *  needed for communicating to the client apps.
 * 
 * @see javax.ws.rs.WebApplicationException
 *
 */
public class ServiceException extends RuntimeException {

	
	private static final long serialVersionUID = -4106321769337595782L;
	
	private final int httpCode;
	
	private final ServiceError error;
	
	/**
	 * Constructor for Service Exception
	 * 
	 * @param errorResource Error enum details
	 * @param args optional arguments to replace placeholders for parameterized messages
	 * 
	 */
	public ServiceException(ResolvableErrorEnum errorResource, String... args) {
		super();
		this.httpCode = ResourceManager.getHttpCode(errorResource);
		this.error = createServiceError(errorResource, args);
	}

	/**
	 * Constructor for Service Exception
	 * 
	 * @param errorResource Error enum details 
	 * @param cause What caused the exception
	 * @param args optional arguments to replace placeholders for parameterized messages
     *
	 */
	public ServiceException(ResolvableErrorEnum errorResource, Throwable cause, String... args) {
		super(cause);
		this.httpCode = ResourceManager.getHttpCode(errorResource);
		this.error = createServiceError(errorResource, args);
	}

	/**
	 * Constructor for Service Exception
	 * 
	 * @param errorResource Error enum details
	 * @param message Error Message of the exception
	 * @param cause What caused the exception
	 * @param args optional arguments to replace placeholders for parameterized messages
	 */
	public ServiceException(ResolvableErrorEnum errorResource,String message, Throwable cause, String... args) {
		super(message, cause);
		this.httpCode = ResourceManager.getHttpCode(errorResource);
		this.error = createServiceError(errorResource, args);
	}

	private ServiceError createServiceError(ResolvableErrorEnum errorResource, String... args) {
		String errorId = ResourceManager.getIdentifier(errorResource);
		String message = ResourceManager.getMessage(errorResource, args);

		return new ServiceError(errorId, message);
	}	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public int getHttpCode() {
		return httpCode;
	}

	public ServiceError getError() {
		return error;
	}
	
	/**
	 * Convenient method to add more detail about the Exception
	 * 
	 * @param detail Error enum details
	*  @param args optional arguments to replace placeholders for parameterized messages
	 * 
	 * @return Service Exception details
	 */
	public ServiceException addDetail(ResolvableErrorEnum detail, String... args) {
		this.getError().addDetail(detail, args);
		return this;
	}
}