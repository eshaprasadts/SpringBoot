package com.att.idp.kafkaref.config;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.att.idp.kafkaref.exception.ServiceException;
import com.att.idp.kafkaref.representation.Error;


/**
 * This class is a exception wrapper class for all rest service exceptions. It creates  Standard SeviceError bean from 
 * ServiceException which is sent as rest output.
 * 
 */
@Provider
public class ServiceExceptionMapper implements ExceptionMapper<ServiceException>  {

	@Override
	public Response toResponse(ServiceException exception) {
		
		Error error = new Error(exception.getError());
		//optionally add links
		//error.setLinks()
		
		return Response.status(exception.getHttpCode())
				.entity(error)
				.type(MediaType.APPLICATION_JSON).build();
	}	
}
	