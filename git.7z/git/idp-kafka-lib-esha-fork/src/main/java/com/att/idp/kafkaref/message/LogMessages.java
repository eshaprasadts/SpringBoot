package com.att.idp.kafkaref.message;

import com.att.eelf.i18n.EELFResolvableErrorEnum;
import com.att.eelf.i18n.EELFResourceManager;

/**
 * This enum consists of Log messages for all resolvable EELF error codes
 *  
 */
public enum LogMessages implements EELFResolvableErrorEnum {

	RESTSERVICE_HELLO, RESTSERVICE_HELLO_NAME, SPRINSERVICE_HELLO, SPRINSERVICE_HELLO_NAME, 
	SPRINSERVICE_HELLO_MESSAGE, SPRINSERVICE_HELLO_MESSAGE_NAME, RESTSERVICE_SAY_HELLO;

	static {

		EELFResourceManager.loadMessageBundle("logmessages");

	}

}