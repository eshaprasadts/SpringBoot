package com.att.idp.kafkaref.repository;

import com.att.idp.kafkaref.model.User;

/**
 * This is the Interface definition for User operations
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */

public interface UserRepository {
	
    /**
     * Method definition which takes User's ID as input 
     *
     * @param userId - ID of the user being searched
     * 
     * @return User - Returns the details of the users being searched
     */

	public User getUser(String userId);

	/**
     * Method definition for User Creation
     *
     * @param user- Object instance of the User to be created
     * 
     * @return User - Returns the details of the users created
     */
	public User createUser(User user);

}
