package com.att.idp.kafkaref.message;

import com.att.idp.kafkaref.i18n.ResolvableErrorEnum;
import com.att.idp.kafkaref.i18n.ResourceManager;

/**
 * This enum consists of error messages for all resolvable error codes
 *  
 */

public enum ErrorMessages implements ResolvableErrorEnum {
	
	ERROR_USER_NOT_FOUND,
	ERROR_DUPLICATE_USER,
	ERROR_STALE_USER_UPDATE,
	
	ERROR_INTERNAL_SERVER,
	
	ERROR_VALIDATION_FAILED,
	ERROR_STRICT_VALIDATION_FAILED,
	ERROR_MINIMAL_VALIDATION_FAILED,
	SUBERROR_VAL_USERID_REQUIRED,
	SUBERROR_VAL_USERID_INVALID,
	SUBERROR_VAL_USERNAME_REQUIRED;
	
	static {
		ResourceManager.loadMessageBundle("errormessages");
	}
}
