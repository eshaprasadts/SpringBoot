package com.att.idp.kafkaref.resource;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import com.att.idp.kafkaref.model.User;
import com.att.idp.kafkaref.model.swagger.UserResponse;

/**
 * This is the Interface definition for User mService
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */
@Api("user")
@Path("/v1/users")
@Produces({MediaType.APPLICATION_JSON})
public interface UserResource {
	
    /**
     * Service definition which takes User's ID as input 
     *
     * @param userId - ID of the user being searched
     * 
     * @return User - Returns the details of the users being searched
     */
	@GET
	@Path("/{userId}")
	@Produces({MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation(
			value = "Get User Resource",
			notes = "For the given user id returns user resource",
			response = UserResponse.class)
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 404, message = "Not Found")					
					})
	public Response getUser(
				@ApiParam(value = "Id of the user to retrieve", required = true) 
				@PathParam("userId")
				String userId);
	
	/**
     * Service definition for User Creation
     *
     * @param user- Object instance of the User to be created
     * 
     * @param uriInfo - Request URI information
     * 
     * @return User - Returns the details of the users created
     */
	@POST
	@Produces({MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_JSON})
	@ApiOperation(
			value = "Create User",
			notes = "Create User, generates Id if not provided")
	@ApiResponses(
			value = {
					@ApiResponse(code = 201, message = "Created"),
					@ApiResponse(code = 409, message = "Conflict")					
					})
	public Response createUser(
				@ApiParam(value = "User to be created", required = true) 
				User user,
				@Context UriInfo uriInfo);
}