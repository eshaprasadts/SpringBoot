package com.att.idp.kafkaref.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * This Class reads and sets all the Web Configurations
 * 
 * 
 */
@Configuration
public class WebConfiguration {

	/**
	 * 
	 * This method provide the MVC control for swagger
	 * 
	 * @return WebMvcConfigurerAdapter
	 */
	@Bean
	public WebMvcConfigurerAdapter forwardToIndex() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addViewControllers(ViewControllerRegistry registry) {
				registry.addViewController("/swagger").setViewName(
						"redirect:/swagger/index.html");
				registry.addViewController("/swagger/").setViewName(
						"redirect:/swagger/index.html");
                registry.addViewController("/docs").setViewName(
                        "redirect:/docs/html/index.html");
                registry.addViewController("/docs/").setViewName(
                         "redirect:/docs/html/index.html");
			}
		};
	}
	
}