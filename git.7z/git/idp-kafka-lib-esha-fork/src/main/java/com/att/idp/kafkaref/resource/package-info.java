/**
 * JAX-RS Root Resource classes.
 * 
 * @see https://docs.oracle.com/javaee/7/tutorial/jaxrs002.htm
 *	
 */
package com.att.idp.kafkaref.resource;