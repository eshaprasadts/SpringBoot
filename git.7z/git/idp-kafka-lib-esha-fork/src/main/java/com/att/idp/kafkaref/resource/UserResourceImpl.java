package com.att.idp.kafkaref.resource;

import javax.ws.rs.core.Link;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.att.idp.kafkaref.exception.ServiceException;
import com.att.idp.kafkaref.message.ErrorMessages;
import com.att.idp.kafkaref.model.User;
import com.att.idp.kafkaref.representation.Resource;
import com.att.idp.kafkaref.service.UserService;
 
/**
 * This is the Controller class for User mService
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */
@Controller
public class UserResourceImpl implements UserResource {
	
	//TODO: remove hardcoding for Uri, instead use UriInfo injection 
	//UriInfo injection is on hold due to unittest issue.
	private static String baseUrl = "/v1/users";
	
	@Autowired
	private UserService userService;
	
	@Override
	public Response getUser(String userId) {
		
		User user = userService.getUser(userId);		
		
		//TODO: remove hardcoded link builder
		//Optional, if Hypermedia link to be included in the response
		Link link = Link
					.fromUri(baseUrl)
					.rel("self").build(userId);
		
		Resource<User> resource = new Resource<>(user);		
		return Response.ok(resource).links(link).build();		
	}

	@Override
	public Response createUser(User user, UriInfo uriInfo) {
		
		
		//validation
		if(user == null || user.getName() == null) {
			//throw ServiceException with details
			throw new ServiceException(ErrorMessages.ERROR_VALIDATION_FAILED)
				.addDetail(ErrorMessages.SUBERROR_VAL_USERNAME_REQUIRED);
		}		

		User created = userService.createUser(user);
		
		UriBuilder builder = uriInfo.getRequestUriBuilder();
		builder.path(created.getId());
		return Response.created(builder.build()).build();		
	}
	
}