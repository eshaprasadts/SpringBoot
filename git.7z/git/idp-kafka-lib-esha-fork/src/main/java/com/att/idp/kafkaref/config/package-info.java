/**
 * Classes for the application configuration
 * 
 * e.g. Container configuraiton such as spring, web, etc
 *
 */
package com.att.idp.kafkaref.config;