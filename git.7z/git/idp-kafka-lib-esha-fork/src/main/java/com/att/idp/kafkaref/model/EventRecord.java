package com.att.idp.kafkaref.model;

import java.io.Serializable;

public class EventRecord implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String eventKey;
	
	private Object eventData;

	public String getEventKey() {
		return eventKey;
	}

	public void setEventKey(String eventKey) {
		this.eventKey = eventKey;
	}

	public Object getEventData() {
		return eventData;
	}

	public void setEventData(Object eventData) {
		this.eventData = eventData;
	}
}
