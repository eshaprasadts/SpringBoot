package com.att.idp.kafkaref.repository;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.idp.kafkaref.eventhandler.producer.EventProducer;
import com.att.idp.kafkaref.model.User;
/**
 * Repository implementation using HashMap as store
 */
@Repository
public class UserRepositoryImpl implements UserRepository {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(UserRepositoryImpl.class);
	
	private Map<String, User> repo = new ConcurrentHashMap<>();
	
	@Autowired
	private EventProducer createUsr;

	@Value("${topic.mapping.createUser}")
	private String topic;

	@Override
	public User getUser(String userId) {
		if(log.isInfoEnabled()) {
			log.info("getUser called for userId : " + userId);
		}

		return repo.get(userId);

	}

	@Override
	public User createUser(User user) {
		if(log.isDebugEnabled()) {
			log.debug("create user called.............." + user);
		}
		
		if(user.getId() == null || user.getId().isEmpty()) {
			if(log.isDebugEnabled()) {
				log.debug("user Id is empty, generating with default mechanism");
			}
			user.setId(UUID.randomUUID().toString());
		}

		createUsr.sendEvent(topic,user.getId(),user);
		repo.put(user.getId(), user);
		
		return user;
	}	


}
