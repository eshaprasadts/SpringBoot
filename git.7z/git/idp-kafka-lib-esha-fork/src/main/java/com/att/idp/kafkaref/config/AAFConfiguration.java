package com.att.idp.kafkaref.config;


import javax.servlet.Filter;
import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.ajsc.aaf.interceptors.AAFPreInterceptor;
import com.att.cadi.PropAccess;
import com.att.cadi.filter.CadiFilter;
/**
 * 
 * 
 * @author kp7466
 *
 */
@SuppressWarnings("unused")
@ConditionalOnProperty(value="idp.aaf.enabled", matchIfMissing=false)
@Configuration
public class AAFConfiguration {
	
	@Value("${cadi.properties}")
	private String cadiPropFile;
	
	/**
	 * This method returns an instance of the AAF Pre Interceptor
	 * 
	 * @return returns a AAF Pre Interceptor instance
	 */
	@Bean
	public AAFPreInterceptor aafPreInterceptor() {
		return new AAFPreInterceptor();
	}

	/**
	 * This method returns an instance of CADI Filter
	 * 
	 * @return returns a CADI Filter instance
	 */
	@Bean(name = "cadiFilter")
	public Filter cadiFilter() throws ServletException {
		return new CadiFilter(true, propAccess());
	}

	/**
	 * This method creates an instance of FilterRegistrationBean, 
	 * sets the filter object, Url Patterns, Name & Order and returns it
	 * 
	 * @return returns a FilterRegistratioBean 
	 */
	@Bean
	public FilterRegistrationBean cadiFilterRegistration() throws ServletException {
		FilterRegistrationBean registration = new FilterRegistrationBean();
		registration.setFilter(cadiFilter());
		registration.addUrlPatterns("/*");
		registration.setName("cadiFilter");
		registration.setOrder(0);
		return registration;
	}	
	
	/**
	 * This method returns an instance of PropAccess with
	 * details of the CADI Property File
	 * 
	 * @return returns a PropAccess instance
	 */
	@Bean
	public PropAccess propAccess() {
		
		StringBuilder sbPath = new StringBuilder();

		sbPath.append("cadi_prop_files=");
		sbPath.append(cadiPropFile);
		PropAccess access = new PropAccess(new String[] { sbPath.toString() });
		return access;
	}
	
}