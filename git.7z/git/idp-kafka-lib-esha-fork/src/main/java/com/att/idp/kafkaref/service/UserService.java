package com.att.idp.kafkaref.service;

import com.att.idp.kafkaref.model.User;

/**
 * This is the Service definition for User mService
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */

public interface UserService {
    /**
     * Service definition which takes User's ID as input 
     *
     * @param userId - ID of the user being searched
     * 
     * @return User - Returns the details of the users being searched
     */
	public User getUser(String userId);	

	/**
     * Service definition for User Creation
     *
     * @param user- Object instance of the User to be created
     *
     * @return User - Returns the details of the users created
     */
	public User createUser(User user);

	/**
     * Service definition for User Updates
     *
     * @param user- Object instance of the User to be updated
     *
     * @return User - Returns the details of the user updated
     */
	public User updateUser(User user);	

}
