/**
 * Classes for the custom exceptions thrown by the application
 *
 */
package com.att.idp.kafkaref.exception;