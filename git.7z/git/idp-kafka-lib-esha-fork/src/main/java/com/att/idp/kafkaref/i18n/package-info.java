/**
 * IDP framework related classses for internationalization and resource bundle.
 *
 */
package com.att.idp.kafkaref.i18n;