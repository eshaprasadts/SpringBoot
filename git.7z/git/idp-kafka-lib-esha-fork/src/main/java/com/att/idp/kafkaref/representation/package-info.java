/**
 * REST Representation classes such as Collection, Error, (Generic) Resource
 * 
 * Please refer article for detailed information on "Representation".
 * 
 * @see https://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm
 *
 */
package com.att.idp.kafkaref.representation;