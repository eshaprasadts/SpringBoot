package com.att.idp.kafkaref.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.AbstractMessageListenerContainer.AckMode;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.att.idp.kafkaref.eventhandler.consumer.EventConsumer;
import com.att.idp.kafkaref.model.EventRecord;

@Configuration
@EnableKafka
public class KafkaConsumerConfig {

	@Value("${kafka.consumer.bootstrap-servers}")
	private String bootstrapServers;

	@Value("${kafka.consumer.group-id}")
	private String groupID;

	@Value("${kafka.consumer.auto-offset-reset}")
	private String offsetConfig;

	@Value("${kafka.consumer.enable-auto-commit}")
	private boolean autoCommit;

	@Bean
	public Map<String, Object> consumerConfigs() {
		Map<String, Object> props = new HashMap<>();
		// list of host:port pairs used for establishing the initial connections to the
		// Kafka cluster
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		// allows a pool of processes to divide the work of consuming and processing
		// records
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		// automatically reset the offset to the earliest offset
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetConfig);

		return props;
	}

	@Bean
	public Map<String, Object> consumerManualConfigs() {
		Map<String, Object> props = new HashMap<>();
		// list of host:port pairs used for establishing the initial connections to the
		// Kafka cluster
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		// allows a pool of processes to divide the work of consuming and processing
		// records
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		// automatically reset the offset to the earliest offset
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "30000");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetConfig);
		props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "3");
		
		return props;
	}
	
	@Bean
	public ConsumerFactory<String, EventRecord> consumerFactory() {
		// JsonDeserializer cannot be set as configProperties
		JsonDeserializer<EventRecord> valueDeserializer = new JsonDeserializer<>(EventRecord.class);
		return new DefaultKafkaConsumerFactory<>(consumerConfigs(), new StringDeserializer(),
				valueDeserializer);
	}

	@Bean
	public ConsumerFactory<String, EventRecord> consumerManualFactory() {
		// JsonDeserializer cannot be set as configProperties
		JsonDeserializer<EventRecord> valueDeserializer = new JsonDeserializer<>(EventRecord.class);
		return new DefaultKafkaConsumerFactory<>(consumerManualConfigs(), new StringDeserializer(),
				valueDeserializer);
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, EventRecord> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, EventRecord> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		factory.setConcurrency(1);
		factory.getContainerProperties().setAckMode(AckMode.RECORD);
		return factory;
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, EventRecord> manualListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, EventRecord> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerManualFactory());
		factory.setConcurrency(1);
		factory.getContainerProperties().setAckMode(AckMode.MANUAL);
		return factory;
	}

	@Bean
	public EventConsumer receiver() {
		return new EventConsumer();
	}
}