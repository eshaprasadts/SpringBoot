package com.att.idp.kafkaref.eventhandler.consumer;

import java.util.concurrent.CountDownLatch;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.idp.kafkaref.model.EventRecord;


public class EventConsumer {

  private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EventConsumer.class);
  
  private int count=0;

  private CountDownLatch latch = new CountDownLatch(1);
  private CountDownLatch latch1 = new CountDownLatch(1);
  
  public CountDownLatch getLatch() {
    return latch;
  }

  @KafkaListener(topics = "${topic.mapping.createUser}" , containerFactory = "kafkaListenerContainerFactory")
  public void receiveEvent(EventRecord data) {
    log.info("received payload='{}' ",data.toString());
    log.info(data.getEventKey());
    log.info(data.getEventData().toString());
  }
  
  @KafkaListener(topics = "${topic.mapping.batchUser}" , containerFactory = "manualListenerContainerFactory")
  public void receiveBatchEvent(EventRecord data, Acknowledgment ack) {
    log.info("Manual payload='{}' ",data.toString());
    log.info(data.getEventKey());
    log.info(data.getEventData().toString());
    count++;
    if (count%5==0) {
    	ack.acknowledge();
    	log.info("Acknowledged");
    }
  }
  
  @KafkaListener(id = "multipart1", topicPartitions = { @TopicPartition(topic = "${topic.mapping.multiUser}", partitions = { "0" }) }, containerFactory = "manualListenerContainerFactory")
  public void receiveMultiEvent(EventRecord data, Acknowledgment ack) {
    log.info("Manual partition payload='{}' of "+Thread.currentThread().getId());
    log.info(data.getEventKey());
    log.info(data.getEventData().toString());
    count++;
    if (count%3==0) {
    	ack.acknowledge();
    	log.info("Acknowledged from partition 0");
    }
    latch.countDown();
  }

  @KafkaListener(id = "multipart2", topicPartitions = { @TopicPartition(topic = "${topic.mapping.multiUser}", partitions = { "1" }) }, containerFactory = "manualListenerContainerFactory")
  public void receiveMultiEvent1(EventRecord data, Acknowledgment ack) {
	  log.info("Manual partition payload='{}' of "+Thread.currentThread().getId());
    log.info(data.getEventKey());
    log.info(data.getEventData().toString());
    count++;
    if (count%3==0) {
    	ack.acknowledge();
    	log.info("Acknowledged from partition 1");
    }
    latch1.countDown();
  }

}