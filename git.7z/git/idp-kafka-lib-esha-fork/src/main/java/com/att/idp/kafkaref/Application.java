package com.att.idp.kafkaref;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.cache.annotation.EnableCaching;

import com.att.ajsc.common.utility.MDCInitializer;
import com.att.ajsc.common.utility.SystemPropertiesLoader;

/**
 * This is the main Class which enables the mS to run as a sprint boot application
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */

@SpringBootApplication
@ComponentScan(basePackages = "com")
@EnableAsync
@EnableCaching
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class })
public class Application extends SpringBootServletInitializer {
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Application.class);
    }
    
    /**
     * This is the main method which invokes mS as Sprint boot App 
     * 
     * @param args Command line parameters if any
     * 
     */
    public static void main(String[] args) {
    	SystemPropertiesLoader.addSystemProperties(); 
    	MDCInitializer.initMDCData();
    	MDCInitializer.setThreadId();
        SpringApplication.run(Application.class, args);
    }
    
}