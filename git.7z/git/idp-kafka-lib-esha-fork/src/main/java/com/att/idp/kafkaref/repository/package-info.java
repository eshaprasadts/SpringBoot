/**
 * Repository classes - mediates between domain and data mapping layer(e.g. ORM)/persistence layer. 
 *
 */
package com.att.idp.kafkaref.repository;