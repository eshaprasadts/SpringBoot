package com.att.idp.kafkaref.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


/**
 * Sample user data model
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */
@ApiModel(value = "User")
public class User implements Serializable {
	
	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value="Unique Id of the User")
	private String id;

	@ApiModelProperty(value="Name of the User", required=true)
	private String name;
	
    /**
     * Default Constructor 
     * 
     */
	public User() {
		super();
	}

    /**
     * Constructor with id of the user 
     * 
     * @param id - ID of the User
     * 
     */
	public User(String id) {
		super();
		this.id = id;
	}	

    /**
     * Constructor with id and name of the user 
     * 
     * @param id - ID of the User
     * @param name - name of the User
	 * 
     */
	public User(String id, String name) {
		super();
		setId(id);
		setName(name);
	}	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "{id:" + id + ", name=" + name + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	
	
}
