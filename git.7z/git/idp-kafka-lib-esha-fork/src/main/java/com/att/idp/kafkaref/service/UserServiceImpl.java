package com.att.idp.kafkaref.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.att.idp.kafkaref.eventhandler.producer.EventProducer;
import com.att.idp.kafkaref.model.User;
import com.att.idp.kafkaref.repository.UserRepository;

/**
 * This is the Service implemetation for User mService
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository; 

	/**
	 * Get Users
	 * 
	 * It first lookup the cache (using spring @Cachable annotation), 
	 * If the entry not found in cache, method will be executed to retrieve the user from repository.
	 * 
	 */
	@Override
	@Cacheable("users")
	public User getUser(String userId) {		
		return userRepository.getUser(userId);
	}

	@Override
	@CacheEvict("users")
	public User createUser(User user) {
		return userRepository.createUser(user);
	}
	
	@Override
	public User updateUser(User user) {
		return null;
	}	

}
