package com.att.idp.kafkaref.eventhandler.producer;

import java.util.concurrent.ExecutionException;

import javax.annotation.Resource;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.idp.kafkaref.eventhandler.consumer.EventConsumer;
import com.att.idp.kafkaref.model.EventRecord;

@Component
public class EventProducer {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EventConsumer.class);

	@Resource(name = "MessageProducerTemplate")
	private KafkaTemplate<String, EventRecord> kafkaTemplate;
	
	
	/**
	 * post to kafka based on topic
	 */
	
	public void sendEvent(String topic,String key, Object data) {
		EventRecord event = new EventRecord();
		event.setEventKey(key);
		event.setEventData(data);
		postToKafka(topic,event.getEventKey(),event);
	}

	/**
	 * Kafka topic will be posted
	 * 
	 * @param topic
	 * @param data
	 */
	private void postToKafka(String topic, String key,EventRecord data) {

		try {
			ListenableFuture<SendResult<String, EventRecord>> future = kafkaTemplate.send(topic,key, data);
			future.get();
		} catch (InterruptedException | ExecutionException e) {
			log.error("Error sending to Kafka Topic ", e);
		}
	}

}