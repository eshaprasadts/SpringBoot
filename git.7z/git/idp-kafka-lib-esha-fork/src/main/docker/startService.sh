#!/bin/sh
touch /app.jar

if [ -z "${java_runtime_arguments}" ]; then
	java -Xms75m -Xmx250m  -XX:+UseConcMarkSweepGC  -XX:+CMSIncrementalMode -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.port=1099 -Dcom.sun.management.jmxremote.rmi.port=1099 -Djava.rmi.server.hostname=127.0.0.1 -javaagent:/opt/ajsc/bin/monitoring.jar=8000-/opt/ajsc/etc/config/prometheus_jmx_config.yaml-/opt/ajsc/etc/config/prometheus_application_config.yaml-/metrics -jar /opt/ajsc/bin/app.jar
else
java $java_runtime_arguments -jar /opt/ajsc/bin/app.jar
 fi