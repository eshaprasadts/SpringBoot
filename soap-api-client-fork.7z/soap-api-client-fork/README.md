Soap Api Client Usage
======================

1) Here is the link for code repository

https://codecloud.web.att.com/projects/ST_IDSE/repos/soap-api-client/browse

2) Please add below dependency in your project's pom.xml
&lt;dependency&gt;
	&lt;groupId&gt;com.att.idp&lt;/groupId&gt;
	&lt;artifactId&gt;soap-api-client&lt;/artifactId&gt;
	&lt;version&gt;1.0.0-SNAPSHOT&lt;/version&gt;
&lt;/dependency&gt;

3) Your SOAP Client Class must extend WebServiceGatewaySupport
import com.att.idp.soap.csi.config.CsiSoapClientConfigurer;
@Autowired 
CsiSoapClientConfigurer csiClientConfigurer;


YOUR_CSI_API in code below 

	@PostConstruct
	public void init() {
		if (csiClientConfigurer != null) {
			csiClientConfigurer.configure(this, YOUR_CSI_API);
		}
	}

Refer to \idptraining\src\main\java\com\att\idp\idptraining\integration\ComsClient.java

4) Create your API specific header class which extends AbstractCsiSoapHeader<MessageHeaderInfo>

In that header class implement getHeaderClass to return your API's header class

Refer to com\att\idp\idptraining\integration\ComsHeader.java for the same and to understand how we are constructing the MessageHeader.

5) Have appropriate entries in applications.properties (config input)

apiclient.csi.default.headers.username=csiuser
apiclient.csi.default.headers.password=csipassword
apiclient.csi.coms.logging.enabled=true
apiclient.csi.coms.logging.bodyEnabled=true
apiclient.csi.coms.headers.username=opus
apiclient.csi.coms.headers.password=opustest
apiclient.csi.coms.headers.infversion=86
apiclient.csi.coms.headers.version=220
apiclient.csi.coms.headers.appname=CommonOrderManagementSystem
apiclient.csi.coms.uri=https://csi-tst-q28.it.att.com:28443/Services/com/cingular/csi/coms/InquireOmniOrderDetails.jws
apiclient.csi.coms.marshallerContextpath=com.cingular.csi.csi.namespaces.container._public.inquireomniorderdetailsrequest
apiclient.csi.coms.unmarshallerContextpath=com.cingular.csi.csi.namespaces.container._public.inquireomniorderdetailsresponse