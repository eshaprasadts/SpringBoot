package com.att.idp.soap;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

public class Jaxb2Utils {

	private Jaxb2Utils() {
	}
	
	public static Jaxb2Marshaller getMarshaller(String contextPath) {			
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPath(contextPath);
		return jaxb2Marshaller;
	}
		
}
