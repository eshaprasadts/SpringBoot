package com.att.idp.logging.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;

public final class SoapClientLogger {

	private com.att.idp.soap.config.SOAPApiProperties.LoggingProperties props;
	private com.att.idp.soap.csi.config.CsiSoapApiProperties.LoggingProperties csiProps;

	private static final Logger logger = LoggerFactory.getLogger(SoapClientLogger.class);

	public SoapClientLogger(com.att.idp.soap.config.SOAPApiProperties.LoggingProperties props) {
		super();
		this.props = props;
	}

	public SoapClientLogger(com.att.idp.soap.csi.config.CsiSoapApiProperties.LoggingProperties csiProps) {
		super();
		this.csiProps = csiProps;
	}

	public void printRequestLine(StringBuilder strBuffer, MessageContext messageContext) {
		if (null != messageContext.getRequest()) {
			
			SoapMessage sm=	(SoapMessage)	messageContext.getRequest();
			
			
			LogFormatter.prefixId(strBuffer).append(LogFormatter.NOTIFICATION_PREFIX).append("Client out-bound request")
					.append('\n');
			LogFormatter.prefixId(strBuffer).append(LogFormatter.REQUEST_PREFIX)
					.append(messageContext.getRequest()).append('\n')
					.append(sm.getSoapHeader()).append('\n');
			logger.info(strBuffer.toString());
			
		}
	}

	

	    
	    
	/**
	 * Prints Response Line
	 * 
	 * @param strBuffer
	 * @param response
	 */
	public void printResponseLine(StringBuilder strBuffer, MessageContext messageContext) {
		if (null != messageContext.getResponse()) {
			SoapMessage sm=	(SoapMessage)	messageContext.getResponse();
			sm.getSoapHeader();
			LogFormatter.prefixId(strBuffer).append(LogFormatter.NOTIFICATION_PREFIX)
					.append("Client out-bound response").append('\n');
			LogFormatter.prefixId(strBuffer).append(LogFormatter.RESPONSE_PREFIX)
					.append(messageContext.getRequest()).append('\n')
					.append(sm.getSoapHeader()).append('\n');
			
			logger.info(strBuffer.toString());

		}
	}

	public boolean logRequest(final MessageContext messageContext) {
		long startTime = System.nanoTime();
		logger.debug("handleRequest");
		try {
			ByteArrayOutputStream reqByArOpSteam = new ByteArrayOutputStream();
			final StringBuilder strBuilder = new StringBuilder();
			if (logger.isInfoEnabled()) {
				printRequestLine(strBuilder, messageContext);
			}
			if (reqByArOpSteam != null && messageContext.getRequest() != null) {
				messageContext.getRequest().writeTo(reqByArOpSteam);
				String payload = reqByArOpSteam.toString(java.nio.charset.StandardCharsets.UTF_8.name());

				if (logger.isDebugEnabled()) {
					logger.debug(payload);
				}
			}

		} catch (IOException e) {
			throw new WebServiceClientException("Can not write the SOAP request into the out stream", e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}

		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		loggingDuration(duration);
		return true;
	}

	public boolean logResponse(final MessageContext messageContext) {

		long startTime = System.nanoTime();
		logger.debug("handleResponse");
		try {
			ByteArrayOutputStream resbuffer = new ByteArrayOutputStream();
			final StringBuilder strBuffer = new StringBuilder();
			if (logger.isInfoEnabled()) {
				printResponseLine(strBuffer, messageContext);
			}
			if (resbuffer != null && messageContext.getResponse() != null) {
				messageContext.getResponse().writeTo(resbuffer);
				String responseString = resbuffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());

				if (logger.isDebugEnabled()) {
					logger.debug(responseString);
				}
			}

		} catch (IOException e) {
			throw new WebServiceClientException("Can not write the SOAP request into the out stream", e) {

				/**
				 * 
				 */
				private static final long serialVersionUID = 1L;
			};
		}

		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		loggingDuration(duration);
		return true;
	}

	public boolean logFault(final MessageContext messageContext) {

		long startTime = System.nanoTime();
		logger.debug("handleFault");
		try {

			ByteArrayOutputStream resbuffer = new ByteArrayOutputStream();
			final StringBuilder strBuffer = new StringBuilder();
			if (logger.isInfoEnabled()) {
				printResponseLine(strBuffer, messageContext);
			}
			if (resbuffer != null && messageContext.getResponse() != null) {
				messageContext.getResponse().writeTo(resbuffer);
				String faultMessage = resbuffer.toString(java.nio.charset.StandardCharsets.UTF_8.name());

				if (logger.isDebugEnabled()) {
					logger.debug(faultMessage);
				}
			}

		} catch (IOException e) {
			logger.error("Error in handleFault", e);
		} finally {
		}

		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		loggingDuration(duration);

		return true;
	}

	private void loggingDuration(long duration) {
		logger.info("Logging Duration : " + duration + " ns");
	}

}
