package com.att.idp.ws.interceptor;

import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;

import io.opentracing.Scope;
import io.opentracing.Tracer;
import io.opentracing.tag.Tags;
import io.opentracing.util.GlobalTracer;

import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class TracingClientInterceptor implements ClientInterceptor {

	private static final Logger logger = LoggerFactory.getLogger(TracingClientInterceptor.class);

	public TracingClientInterceptor(Tracer tracer) {

	}
	
	 private static final String OPENTRACING_TRACE_ID = "idp-trace-id"; 
	 private  static final String PREV_OPENTRACING_TRACE_ID = "current-idp-trace-id";
	 

	@Override
	public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
    boolean result=false;
		String prevTraceId;

		SoapMessage sm = (SoapMessage) messageContext.getRequest();
		SoapHeader soapHeader = sm.getSoapHeader();
		String sourceName = soapHeader.getSource().toString();
		

		if (GlobalTracer.isRegistered()) {
			Tracer tracer = GlobalTracer.get();

			
	        if (MDC.get(OPENTRACING_TRACE_ID)!=null 
	        		&& GlobalTracer.get().activeSpan().toString()!=null && 
	        		!GlobalTracer.get().activeSpan().toString().isEmpty()) {
			
			  prevTraceId = MDC.get(OPENTRACING_TRACE_ID);
			  MDC.put(PREV_OPENTRACING_TRACE_ID, prevTraceId);
			  MDC.put(OPENTRACING_TRACE_ID, GlobalTracer.get().activeSpan().toString());
			 
	        }
			String spanText = "soap-client" + sourceName;
			Tracer.SpanBuilder spanBuilder = tracer.buildSpan(spanText);
			spanBuilder.withTag(Tags.COMPONENT.getKey(), "soap-client");
			Scope span =  spanBuilder.startActive(true);
			result=true;
		}

		return result;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
		boolean result=false;
		if(MDC.get(PREV_OPENTRACING_TRACE_ID)!=null &&
				MDC.get(OPENTRACING_TRACE_ID)!=null ) {
		
		  String prevTraceID = MDC.get(PREV_OPENTRACING_TRACE_ID);
		  MDC.remove(OPENTRACING_TRACE_ID); 
		  MDC.put(OPENTRACING_TRACE_ID, prevTraceID);
		  MDC.remove(PREV_OPENTRACING_TRACE_ID);
		
			result=true;
		}
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
		return false;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {

		try {
			Tracer tracer = GlobalTracer.get();
			if(tracer.activeSpan()!=null) {
			 tracer.activeSpan().finish();
			}
		} catch (Exception exe) {
			logger.error("Exception while deactivating the span" + exe.getMessage());
		}

	}
}
