package com.att.idp.soap.csi.config;

import com.att.idp.logging.LogLevel;

/**
 * Template for CSI Soap API configuration Properties
 *
 */
public class CsiSoapApiProperties {
	
	private String uri;
	
	private String marshallerContextpath;
	
	private String unmarshallerContextpath;
	
	private LoggingProperties logging;
	
	private CommonHeaders headers;

	public CsiSoapApiProperties() {
		super();
		this.logging = new LoggingProperties();
		this.headers= new CommonHeaders();
	}
	
	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public CommonHeaders getHeaders() {
		return headers;
	}

	public void setHeaders(CommonHeaders headers) {
		this.headers = headers;
	}
	
	public LoggingProperties getLogging() {
		return logging;
	}

	public void setLogging(LoggingProperties logging) {
		this.logging = logging;
	}
	
	
	public String getMarshallerContextpath() {
		return marshallerContextpath;
	}


	public void setMarshallerContextpath(String marshallerContextpath) {
		this.marshallerContextpath = marshallerContextpath;
	}


	public String getUnmarshallerContextpath() {
		return unmarshallerContextpath;
	}


	public void setUnmarshallerContextpath(String unmarshallerContextpath) {
		this.unmarshallerContextpath = unmarshallerContextpath;
	}





	public static class LoggingProperties {

		public LoggingProperties() {
			super();
		}
		
		private LogLevel logLevel;

		public LogLevel getLogLevel() {
			return logLevel;
		}

		public void setLogLevel(LogLevel logLevel) {
			this.logLevel = logLevel;
		}
		

		
	}
	
	
	public static class CommonHeaders {
		
		public CommonHeaders() {
			super();
		}
		private String username;
		private String password;
		private String infversion;
		private String version;
		private String timeToLive;
		private String appname;
		
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getInfversion() {
			return infversion;
		}
		public void setInfversion(String infversion) {
			this.infversion = infversion;
		}
		public String getVersion() {
			return version;
		}
		public void setVersion(String version) {
			this.version = version;
		}
		public String getTimeToLive() {
			return timeToLive;
		}
		public void setTimeToLive(String timeToLive) {
			this.timeToLive = timeToLive;
		}
		public String getAppname() {
			return appname;
		}
		public void setAppname(String appname) {
			this.appname = appname;
		}
	}


}

	
