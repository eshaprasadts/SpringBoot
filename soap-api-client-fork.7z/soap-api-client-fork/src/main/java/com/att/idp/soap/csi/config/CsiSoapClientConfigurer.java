package com.att.idp.soap.csi.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;

import com.att.idp.logging.client.SoapClientLogger;
import com.att.idp.soap.Jaxb2Utils;
import com.att.idp.ws.interceptor.SoapClientLoggingInterceptor;
import com.att.idp.ws.interceptor.TracingClientInterceptor;

import io.opentracing.Tracer;
import io.opentracing.util.GlobalTracer;

/**
 * This class holds configuration specific to soap-api-clients in an application
 * 
 */
/**
 * @author ep887j
 *
 */

@Component
public class CsiSoapClientConfigurer {

	@Autowired
	private CsiSoapClientConfig csiClientConfig;
/*	private Tracer tracer;*/

	public WebServiceGatewaySupport configure(WebServiceGatewaySupport client, String api) {
		
		CsiSoapApiProperties apiProps = csiClientConfig.getProperties(api);		
		
		configureClient(client, apiProps);
		
		configureTemplate(client.getWebServiceTemplate(), apiProps);

		return client;
	}
	
	/** returns CsiSoapClientConfig
	 * @return CsiSoapClientConfig
	 */
	public CsiSoapClientConfig getCsiClientConfig() {
		return csiClientConfig;
	}

	
	/** 
	 * Configures Client with Marshler and Unmarshler
	 * @param client
	 * @param apiProps
	 * @return WebServiceGatewaySupport
	 */
	private WebServiceGatewaySupport configureClient(WebServiceGatewaySupport client, CsiSoapApiProperties apiProps) {
		client.setDefaultUri(apiProps.getUri());
		client.setMarshaller(Jaxb2Utils.getMarshaller(apiProps.getMarshallerContextpath()));
		client.setUnmarshaller(Jaxb2Utils.getMarshaller(apiProps.getUnmarshallerContextpath()));		
		return client;
	}
	
	
	/** 
	 * configures WebServiceTemplate with Custom Interceptors to address cross cutting concerns 
	 * 
	 * @param template
	 * @param apiProps
	 */
	private void configureTemplate(WebServiceTemplate template, CsiSoapApiProperties apiProps) {
			 Tracer tracer=GlobalTracer.get();
		// register the LogHttpHeaderClientInterceptor
		ClientInterceptor[] interceptors = new ClientInterceptor[] {
	     	new TracingClientInterceptor(tracer),
				new SoapClientLoggingInterceptor(new SoapClientLogger(apiProps.getLogging()))
				};
		template.setInterceptors(interceptors);
	}
}


