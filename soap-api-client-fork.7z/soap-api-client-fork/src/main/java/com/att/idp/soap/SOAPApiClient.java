package com.att.idp.soap;
/**
 * Marker Interface for SOAPApiClient
 *
 */
public interface SOAPApiClient {

}
