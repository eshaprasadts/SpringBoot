package com.att.idp.ws.interceptor;

import javax.xml.transform.Source;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import com.att.idp.logging.client.SoapClientLogger;

import io.opentracing.util.GlobalTracer;

public class SoapClientLoggingInterceptor implements ClientInterceptor {

	private static final String OPENTRACING_TRACE_ID = "idp-trace-id";
	private SoapClientLogger soapClientLogger;
	private static final Logger logger = LoggerFactory.getLogger(SoapClientLoggingInterceptor.class);
	

	public SoapClientLoggingInterceptor(SoapClientLogger soapClientLogger) {
		super();
		this.soapClientLogger = soapClientLogger;
	}

	@Override
	public boolean handleFault(final MessageContext messageContext) {
		logger.debug("handleFault");
		soapClientLogger.logFault(messageContext);
		return true;
	}

	protected Source getSource(SaajSoapMessage saajSoapMessage) {
		if (saajSoapMessage != null) {
			return saajSoapMessage.getEnvelope().getSource();
		}
		return null;
	}

	@Override
	public boolean handleRequest(final MessageContext messageContext) {
		logger.debug("handleRequest");
		logger.debug("OPENTRACING_TRACE_ID"+ GlobalTracer.get().activeSpan().toString());
		 
		MDC.put(OPENTRACING_TRACE_ID, GlobalTracer.get().activeSpan().toString());
		soapClientLogger.logRequest(messageContext);
		
		return true;
	}

	@Override
	public boolean handleResponse(final MessageContext messageContext) {
		logger.debug("handleResponse");
		soapClientLogger.logResponse(messageContext);
		
		return true;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {
	}
}