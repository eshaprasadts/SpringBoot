package com.att.idp.soap.config;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;

import com.att.idp.logging.client.SoapClientLogger;
import com.att.idp.ws.interceptor.SoapClientLoggingInterceptor;

/**
 * This class holds configuration specific to rest-api-clients in an application
 * 
 */
@Component
@ConfigurationProperties(prefix = "apiclient")
public class SOAPClientConfigurer {

	private static final Logger logger = LoggerFactory.getLogger(SOAPClientConfigurer.class);

	/**
	 * Auto populated by spring by convention Properties prefixed with
	 * 'apiclient.soap' will be loaded in this map
	 */
	private Map<String, SOAPApiProperties> soap;

	public SOAPApiProperties getProperties(String api) {

		if (api == null) {
			throw new IllegalArgumentException("api can not be null");
		}

		SOAPApiProperties apiProps = null;
		SOAPApiProperties defaultProps = null;

		if (soap != null) {
			apiProps = soap.get(api);
			defaultProps = soap.get("default");
		}

		// if no specific AND default configuration, return null
		if (apiProps == null && defaultProps == null) {
			return null;
		}

		// if no default, return specific configuration (NotNull)
		if (defaultProps == null) {
			return apiProps;
		}

		// initialize with empty if apiProps is null, as it may get populated from
		// defaultProps
		apiProps = (apiProps != null) ? apiProps : new SOAPApiProperties();

		apiProps.setLogging(((apiProps.getLogging() == null ? defaultProps.getLogging() : apiProps.getLogging())));

		return apiProps;
	}

	public Map<String, SOAPApiProperties> getSoap() {
		return soap;
	}

	public void setSoap(Map<String, SOAPApiProperties> soap) {
		this.soap = soap;
	}

	public WebServiceGatewaySupport configure(WebServiceGatewaySupport webServiceGatewaySupportChild, String api) {

		SOAPApiProperties apiProps = getProperties(api);
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		if (apiProps.getMarshallerContextpath() != null && (!apiProps.getMarshallerContextpath().isEmpty())) {
			jaxb2Marshaller.setContextPath(apiProps.getMarshallerContextpath());
		}
		webServiceGatewaySupportChild.setDefaultUri(apiProps.getUri());
		webServiceGatewaySupportChild.getWebServiceTemplate().setDefaultUri(apiProps.getUri());

		Map<String, Object> map = new HashMap<>();
		map.put(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		map.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxb2Marshaller.setMarshallerProperties(map);

		webServiceGatewaySupportChild.getWebServiceTemplate().setMarshaller(jaxb2Marshaller);
		webServiceGatewaySupportChild.getWebServiceTemplate().setUnmarshaller(jaxb2Marshaller);

		// register the LogHttpHeaderClientInterceptor
		ClientInterceptor[] interceptors = new ClientInterceptor[] { new SoapClientLoggingInterceptor(
				new SoapClientLogger(apiProps.getLogging())) /* , new SoapTracerInterceptor() */ };
		webServiceGatewaySupportChild.getWebServiceTemplate().setInterceptors(interceptors);

		return webServiceGatewaySupportChild;
	}
}