package com.att.idp.soap.config;

/**
 * Template for SOAP API configuration Properties
 *
 */

public class SOAPApiProperties {

	private String uri;

	private String marshallerContextpath;

	private String unmarshallerContextpath;

	private LoggingProperties logging;


	public SOAPApiProperties() {
		super();
		this.logging = new LoggingProperties();
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}


	public LoggingProperties getLogging() {
		return logging;
	}

	public void setLogging(LoggingProperties logging) {
		this.logging = logging;
	}

	public String getMarshallerContextpath() {
		return marshallerContextpath;
	}

	public void setMarshallerContextpath(String marshallerContextpath) {
		this.marshallerContextpath = marshallerContextpath;
	}

	public String getUnmarshallerContextpath() {
		return unmarshallerContextpath;
	}

	public void setUnmarshallerContextpath(String unmarshallerContextpath) {
		this.unmarshallerContextpath = unmarshallerContextpath;
	}

	public static class LoggingProperties {

		public LoggingProperties() {
			super();
		}

		public boolean isLogLevel() {
			return logLevel;
		}

		public void setLogLevel(boolean logLevel) {
			this.logLevel = logLevel;
		}

		private boolean logLevel;

	

	}


}
