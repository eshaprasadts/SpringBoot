package com.att.idp.soap.csi.config;

import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.att.idp.soap.csi.config.CsiSoapApiProperties.CommonHeaders;
/**
 * This class holds config specific to csiapiclients in an application
 * 
 */
@Component
@ConfigurationProperties(prefix = "apiclient")
public class CsiSoapClientConfig implements InitializingBean {
	
	private static CsiSoapClientConfig instance;
	
	public static CsiSoapClientConfig getInstance() {
		return instance;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		instance = this;		
	}

	/**
	 * Auto populated by spring by convention
	 * Properties prefixed with 'apiclient.csi' will be loaded in this map
	 */
	private Map<String, CsiSoapApiProperties> csi;

	public CsiSoapApiProperties getProperties(String api) {
		
		if(api == null) {
			throw new IllegalArgumentException("api is can not be null");
		}

		CsiSoapApiProperties apiProps = null;			
		CsiSoapApiProperties defaultProps = null;
		
		if(csi != null) {				
			apiProps = csi.get(api);			
			defaultProps = csi.get("default");				
		}
		
		//if no specific AND default config, return null
		if(apiProps == null && defaultProps ==null) {
			return null;
		}
		
		//if no default, return specific config (NotNull)
		if(defaultProps == null) {
			return apiProps;
		}
		
		//initialize with empty if apiProps is null, as it may get populated from defaultProps
		apiProps = (apiProps != null) ? apiProps : new CsiSoapApiProperties();
		
		CommonHeaders apiHeaders = apiProps.getHeaders();
		CommonHeaders defaultHeaders = defaultProps.getHeaders();
		
		//merge with default if specific config is missing
		apiHeaders.setUsername((apiHeaders.getUsername() == null ? defaultHeaders.getUsername(): apiHeaders.getUsername()));
		apiHeaders.setPassword((apiHeaders.getPassword() ==null ? defaultHeaders.getPassword(): apiHeaders.getPassword()));
		
		apiProps.setLogging(((apiProps.getLogging() ==null? defaultProps.getLogging(): apiProps.getLogging())));
		
		return apiProps;
	}

	public Map<String, CsiSoapApiProperties> getCsi() {
		return csi;
	}

	public void setCsi(Map<String, CsiSoapApiProperties> csi) {
		this.csi = csi;
	}



}
