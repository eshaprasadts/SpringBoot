package com.att.idp.soap.csi.config;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

/** 
 * Its an inner class to Construct header Object needed for CSI call
 * @author ep887j
 *
 */
public abstract class AbstractCsiSoapHeader<T> implements WebServiceMessageCallback  {

	private final Logger log = LoggerFactory.getLogger(AbstractCsiSoapHeader.class);
	
	private String apiName;
	
	private String conversationId;	
	
	public AbstractCsiSoapHeader(String apiName) {
		super();
		this.apiName = apiName;	
	}
	
	/** returns apiName
	 * @return apiName
	 */
	protected String getApiName() {
		return apiName;
	}
	
	/**
	 * Once the Client gets the conversation Id the same might have to be set on
	 * further conversationsal requests
	 * 
	 * @param conversationId
	 * @return
	 */
	public AbstractCsiSoapHeader withConversationId(String conversationId) {
		this.conversationId = conversationId;
		return this;
	} 
	
	/**
	 * Gets the Object Type for Header
	 * This needs to be implemented by Child class to specify 
	 * Message Header Class specific to the API
	 * @return
	 */
	abstract protected Class<?> getHeaderClass() ;		
	
	
	@Override
    public void doWithMessage(WebServiceMessage message) {
        // get the header from the SOAP message
        SoapHeader soapHeader = ((SoapMessage) message).getSoapHeader();
        
        JAXBElement<T> header = csiMessageHeader();
        
        // create a marshaller
        JAXBContext context;
		try {
			context = JAXBContext.newInstance(getHeaderClass());
	        Marshaller marshaller = context.createMarshaller();
	        // marshal the headers into the specified result
	        marshaller.marshal(header, soapHeader.getResult());  
		} catch (JAXBException e) {
			log.error("AbstractCsiSoapHeader cannot be created", e);
		}
    }	
	
	/**
	 * Generates Random Unique Message Id
	 * @param msgIdPrefix
	 * @return
	 */
	protected String getGeneratedMsgId(String msgIdPrefix)
	   {
	      return msgIdPrefix + "-" + RandomStringUtils.randomAlphabetic(10).toUpperCase();
	   }
	
	
	protected abstract JAXBElement<T> csiMessageHeader();
}

