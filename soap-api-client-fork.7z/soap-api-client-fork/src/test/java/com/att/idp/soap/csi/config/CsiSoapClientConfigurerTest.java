package com.att.idp.soap.csi.config;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import org.mockito.Mockito;



@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = WebEnvironment.NONE)
public class CsiSoapClientConfigurerTest {
	
	
	private WebServiceGatewaySupport wsgs;
	
	private CsiSoapApiProperties apiProps;
	
	class WebServiceGatewaySupportImpl extends WebServiceGatewaySupport{
		
	}
	
	String api ="api1";

	
	@Before
	public void setUp() throws Exception {
		wsgs=Mockito.mock( WebServiceGatewaySupportImpl.class);
		apiProps=Mockito.mock( CsiSoapApiProperties.class);
		api ="api1";

	}
	
	@Autowired
	private CsiSoapClientConfigurer csiConfigurer;
	
	@Test
	public void  testGetCsiClientConfig() {
		assert(csiConfigurer.getCsiClientConfig() instanceof CsiSoapClientConfig);
	}


	
}
