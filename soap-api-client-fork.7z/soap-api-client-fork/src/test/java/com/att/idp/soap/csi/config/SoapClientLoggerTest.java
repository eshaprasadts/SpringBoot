package com.att.idp.soap.csi.config;


import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.context.MessageContext;

import com.att.idp.logging.client.SoapClientLogger;
import com.att.idp.soap.csi.config.CsiSoapClientConfig;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = WebEnvironment.NONE)
public class SoapClientLoggerTest {

	@Autowired
	CsiSoapClientConfig csiSoapClientConfig;
	MessageContext messageContext;

    private com.att.idp.soap.csi.config.CsiSoapApiProperties.LoggingProperties csiProps;

	@Before
	public void setUp() throws Exception {
		this.csiProps = csiSoapClientConfig.getProperties("api1").getLogging();
		this.messageContext=Mockito.mock(MessageContext.class);
		}

	@After
	public void tearDown() throws Exception {

	}

	private SoapClientLogger createTestSubject() {
		return new SoapClientLogger(csiProps);
	}

	@Test
	public void testLogFault() throws Exception {
		SoapClientLogger testSubject;
		// default test
		testSubject = createTestSubject();
		assertTrue(testSubject.logFault(this.messageContext));
	}

	@Test
	public void testLogRequest() throws Exception {
		SoapClientLogger testSubject;
		// default test
		testSubject = createTestSubject();
		assertTrue(testSubject.logRequest(this.messageContext));
	}

	@Test
	public void testLogResponse() throws Exception {
		SoapClientLogger testSubject;
		// default test
		testSubject = createTestSubject();
		assertTrue(testSubject.logResponse(this.messageContext));
	}



}