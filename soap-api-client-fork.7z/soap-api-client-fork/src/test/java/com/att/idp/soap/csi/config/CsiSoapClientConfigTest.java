package com.att.idp.soap.csi.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment = WebEnvironment.NONE)
public class CsiSoapClientConfigTest {
	
	
	@Autowired
	private CsiSoapClientConfig csiClientProps;
	
	@Test
	public void testConfig() {		
		String apiName1="api1";
		String apiName2="api2";

		assertNotNull(csiClientProps);
		assertNotNull(csiClientProps.getProperties(apiName1));
		assertNotNull(csiClientProps.getProperties(apiName2));
		assertNotNull(csiClientProps.getProperties("default"));
		
		//assert that specific headers are loaded
		assertEquals("csiuser", csiClientProps.getProperties(apiName1).getHeaders().getUsername());
		assertEquals("csipassword", csiClientProps.getProperties(apiName1).getHeaders().getPassword());
		assertEquals("86", csiClientProps.getProperties(apiName1).getHeaders().getInfversion());
		assertEquals("220", csiClientProps.getProperties(apiName1).getHeaders().getVersion());

		assertEquals("120000", csiClientProps.getProperties(apiName1).getHeaders().getTimeToLive());
		assertEquals("CommonOrderManagementSystem1", csiClientProps.getProperties(apiName1).getHeaders().getAppname());
		assertNotNull(csiClientProps.getProperties(apiName1).getUri());
		assertNotEquals( "", csiClientProps.getProperties(apiName1).getUri());
		
		assertNotNull(csiClientProps.getProperties(apiName1).getUnmarshallerContextpath());
		assertNotEquals( "", csiClientProps.getProperties(apiName1).getUnmarshallerContextpath());
		
		assertNotNull(csiClientProps.getProperties(apiName1).getMarshallerContextpath());
		assertNotEquals( "", csiClientProps.getProperties(apiName1).getMarshallerContextpath());

		
		//assert the piggyback on default credentials, if not configured
		assertEquals("csiuser" , csiClientProps.getProperties(apiName2).getHeaders().getUsername());
		assertEquals("csipassword" , csiClientProps.getProperties(apiName2).getHeaders().getPassword());
		
		//assert the default config for non-existing api
		assertNotNull(csiClientProps.getProperties("notdefined"));
		assertEquals("csiuser" , csiClientProps.getProperties("notdefined").getHeaders().getUsername());
		assertEquals("csipassword" , csiClientProps.getProperties("notdefined").getHeaders().getPassword());
		
		assertEquals("86", csiClientProps.getProperties(apiName2).getHeaders().getInfversion());
		assertEquals("221", csiClientProps.getProperties(apiName2).getHeaders().getVersion());

		assertEquals("60000", csiClientProps.getProperties(apiName2).getHeaders().getTimeToLive());
		assertEquals("CommonOrderManagementSystem2", csiClientProps.getProperties(apiName2).getHeaders().getAppname());
		assertNotNull(csiClientProps.getProperties(apiName2).getUri());
		assertNotEquals( "", csiClientProps.getProperties(apiName2).getUri());
		
		assertNotNull(csiClientProps.getProperties(apiName2).getUnmarshallerContextpath());
		assertNotEquals( "", csiClientProps.getProperties(apiName2).getUnmarshallerContextpath());
		
		assertNotNull(csiClientProps.getProperties(apiName2).getMarshallerContextpath());
		assertNotEquals( "", csiClientProps.getProperties(apiName2).getMarshallerContextpath());
	}
	
}
