package com.att.idp.ejb.client.test;

import java.beans.IntrospectionException;

import org.junit.Test;

import com.att.idp.ejb.client.config.EJBClientProperties;

public class EJBClientPropertiesTest {

	@Test
	public void test() throws IntrospectionException {
		JavaBeanTester.test(EJBClientProperties.class);
	}

}
