package com.att.idp.ejb.client.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.junit.Test;

import com.att.idp.ejb.client.URLCallbackHandler;

import weblogic.security.auth.callback.URLCallback;

public class URLCallbackHandlerTest {
	@Test
	public void testNamePassUrl() throws UnsupportedCallbackException {
		String user="user";
		String url="url";
		String password="password";
		URLCallbackHandler ucbh=new URLCallbackHandler(user,password,url);
		Callback[] cbs=new Callback[3];		
		NameCallback ncb=new NameCallback("username:");
		cbs[0]=ncb;		
		PasswordCallback pcb=new PasswordCallback("password:", false);
		cbs[1]=pcb;
		URLCallback ucb=new URLCallback("url:");
		cbs[2]=ucb;
		
		ucbh.handle(cbs);
		assertEquals(ncb.getName(),user);
		assertNotNull(pcb.getPassword());
		assertEquals(ucb.getURL(),url);
	}
	
	@Test
	public void testNamePass() throws UnsupportedCallbackException {
		String user="user";
		String password="password";
		URLCallbackHandler ucbh=new URLCallbackHandler(user,password);
		Callback[] cbs=new Callback[2];		
		NameCallback ncb=new NameCallback("username:");
		cbs[0]=ncb;		
		PasswordCallback pcb=new PasswordCallback("password:", false);
		cbs[1]=pcb;
		
		ucbh.handle(cbs);
		assertEquals(ncb.getName(),user);
		assertNotNull(pcb.getPassword());
	}
}
