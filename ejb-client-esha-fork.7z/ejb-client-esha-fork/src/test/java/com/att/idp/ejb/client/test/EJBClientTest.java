package com.att.idp.ejb.client.test;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

import javax.ejb.EJBObject;
import javax.ejb.RemoveException;
import javax.naming.NamingException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.idp.ejb.client.EJBClient;
import com.att.idp.ejb.client.EJBRequest;
import com.uber.jaeger.propagation.TextMapCodec;
import com.uber.jaeger.reporters.LoggingReporter;
import com.uber.jaeger.reporters.Reporter;
import com.uber.jaeger.samplers.ConstSampler;
import com.uber.jaeger.samplers.Sampler;

import io.opentracing.Tracer;
import io.opentracing.propagation.Format;
import io.opentracing.util.GlobalTracer;

// TODO: Auto-generated Javadoc
/**
 * The Class EJBClientTest.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class EJBClientTest {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(EJBClientTest.class);

	/** The ejb client. */
	@Autowired
	EJBClient ejbClient;

	/**
	 * Test EJB home.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public void testEJBHome() throws Exception {
		log.info("----testEJBHome---");

		EJBRequest ejbRequest = new EJBRequest();
		ejbRequest.setProviderName("tlg");
		ejbRequest.setJndiName("amdocsBeans.RefQueryHome");
		ejbRequest.setMethodName("getDealerInfo");
		ejbRequest.setMethodInputs(new String[] { "DLS", "TEST" });

		//
		// Object o=ejbClient.getEJBBean("tlg", "amdocsBeans.RefQueryHome");
		// String[] paramObject={"DLS","TEST"};
		for (int i = 0; i < 10; i++) {
			long start = System.currentTimeMillis();
			ejbClient.invoke(ejbRequest);
			System.out.println((System.currentTimeMillis() - start) + " ms time taken");
		}
		System.out.println("-------------------------------------------------------------------------");
	}
	
	@Test
	public void testEnabler() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, NamingException {
		assertNotNull(ejbClient.getEJBBean("enabler", "amdocsBeans.CM9EventServicesHome"));
	}

	@Test
	public void testResetEJBHome() throws Exception {
		ejbClient.resetEJBHomeBy("tlg");
		
		log.info("----testResetEJBHome---");
		ejbClient.resetEJBHome("tlg", "amdocsBeans.RefQueryHome");		
		
		log.info("Resetting all EJB homes");
		ejbClient.resetAllEJBHomes();
	}

	@Test
	public void testNegative() {
		try {
			ejbClient.invoke(null);
		} catch (Exception e) {
			assertNotNull(e);
		}
		try {
			EJBRequest ejbRequest = new EJBRequest();
			ejbClient.invoke(ejbRequest);
		} catch (Exception e) {
			assertNotNull(e);
		}
		try {
			EJBRequest ejbRequest = new EJBRequest();
			ejbRequest.setJndiName("abc");
			ejbClient.invoke(ejbRequest);
		} catch (Exception e) {
			assertNotNull(e);
		}
		try {
			EJBRequest ejbRequest = new EJBRequest();
			ejbRequest.setProviderName("abc");
			ejbRequest.setJndiName("abc");
			ejbClient.invoke(ejbRequest);
		} catch (Exception e) {
			assertNotNull(e);
		}
		try {
			EJBRequest ejbRequest = new EJBRequest();
			ejbRequest.setProviderName("abc");
			ejbRequest.setJndiName("abc");
			ejbRequest.setMethodName("abcd");
			ejbClient.invoke(ejbRequest);
		} catch (Exception e) {
			assertNotNull(e);
		}
		try {
			EJBRequest ejbRequest = new EJBRequest();
			ejbRequest.setProviderName("abc");
			ejbRequest.setJndiName("abc");
			Object o=(EJBObject)ejbClient.getEJBBean(ejbRequest.getProviderName(), ejbRequest.getJndiName());
			ejbRequest.setRemoteInterface(o);
			ejbRequest.setMethodName("abcd");
			ejbClient.invoke(ejbRequest);
		} catch (Exception e) {
			assertNotNull(e);
		}
	}
	
	@Test
	public void testEJBBean() throws RemoteException, RemoveException {
		log.info("testEJBBean");
		try {
			EJBRequest ejbRequest = new EJBRequest();
			ejbRequest.setProviderName("abc");
			ejbRequest.setJndiName("abc");
			Object o=(EJBObject)ejbClient.getEJBBean("tlg", "xyz");
			ejbRequest.setRemoteInterface(o);
			ejbRequest.setMethodName("abcd");
			ejbClient.invoke(ejbRequest);
		} catch (Exception e) {
			assertNotNull(e);
		}
		for (int i=0;i<3;i++) {
			EJBObject o=null;
			try {
				EJBRequest ejbRequest = new EJBRequest();
				ejbRequest.setProviderName("tlg");
				ejbRequest.setJndiName("amdocsBeans.RefQueryHome");
				ejbRequest.setMethodName("getDealerInfo");
				ejbRequest.setMethodInputs(new String[] { "DLS", "TEST" });
				o=(EJBObject)ejbClient.getEJBBean(ejbRequest.getProviderName(), ejbRequest.getJndiName());
				ejbRequest.setRemoteInterface(o);
				ejbClient.invoke(ejbRequest);
			} catch (Exception e) {
			} finally {
				if (o!=null)
					o.remove();
			}	
		}
	}

	@Test
	public void testEJBClientTracer() throws Exception {
		log.info("----testEJBClient---");

		Reporter reporter = new LoggingReporter();
		Sampler sampler = new ConstSampler(true);

		// Customize for proprietary headers
		TextMapCodec myCodec = new TextMapCodec(true).builder().withSpanContextKey("idp-trace-id")
				.withBaggagePrefix("idpctx-").build();

		Tracer tracer = new com.uber.jaeger.Tracer.Builder("idp", reporter, sampler)
				.registerInjector(Format.Builtin.HTTP_HEADERS, myCodec)
				.registerExtractor(Format.Builtin.HTTP_HEADERS, myCodec).build();
		if (!GlobalTracer.isRegistered()) {
			GlobalTracer.register(tracer);
		}

		EJBRequest ejbRequest = new EJBRequest();
		ejbRequest.setProviderName("tlg");
		ejbRequest.setJndiName("amdocsBeans.RefQueryHome");
		ejbRequest.setMethodName("getDealerInfo");
		ejbRequest.setMethodInputs(new String[] { "DLS", "TEST" });

		for (int i = 0; i < 2; i++) {
			long start = System.currentTimeMillis();
			ejbClient.invoke(ejbRequest);
			System.out.println((System.currentTimeMillis() - start) + " ms time taken");
		}
		System.out.println("-------------------------------------------------------------------------");
	}
}
