package com.att.idp.ejb.client.test;

import java.beans.IntrospectionException;

import org.junit.Test;

import com.att.idp.ejb.client.EJBRequest;

public class EJBRequestTest {

	@Test
	public void test() throws IntrospectionException {
		JavaBeanTester.test(EJBRequest.class);
	}

}
