package com.att.idp.ejb.client.test;

import static org.junit.Assert.assertNotNull;

import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.idp.ejb.client.config.EJBClientConfig;
import com.att.idp.ejb.client.config.EJBClientProperties;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EJBClientConfigTest {
	@Autowired 
	EJBClientConfig config;

	@Test
	public void test() {
		Map<String,EJBClientProperties> m=config.getEjb();
		config.setEjb(null);
		config.setEjb(m);
		assertNotNull(config.getProperties("tlg"));
	}

}
