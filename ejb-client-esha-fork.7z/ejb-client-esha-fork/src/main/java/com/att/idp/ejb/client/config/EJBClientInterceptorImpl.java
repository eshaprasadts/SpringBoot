package com.att.idp.ejb.client.config;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.ejb.client.EJBRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.opentracing.Scope;
import io.opentracing.Tracer;
import io.opentracing.tag.Tags;
import io.opentracing.util.GlobalTracer;

@Aspect
@Component
public class EJBClientInterceptorImpl {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(EJBClientInterceptorImpl.class);

	private static final String NOTIFICATION_PREFIX = "* ";

	private static final String REQUEST_PREFIX = ">> ";

	private static final String RESPONSE_PREFIX = "<< ";

	@Autowired
	private EJBClientConfig ejbConfig;

	@Around("@annotation(EJBClientInterceptor)")
	public Object interceptEJBClient(ProceedingJoinPoint joinPoint) throws Throwable {
		Scope span = null;
		try {
			String methodName = joinPoint.getSignature().getName();
			EJBRequest request = null;

			// Used to get the parameters of the method !
			Object[] arguments = joinPoint.getArgs();
			for (Object object : arguments) {
				if (object instanceof EJBRequest) {
					request = (EJBRequest) object;
				}
			}
			if (request == null) {
				return joinPoint.proceed();
			}
			if (GlobalTracer.isRegistered()) {
				Tracer tracer = GlobalTracer.get();
				String spanText = methodName + ":" + ejbConfig.getProperties(request.getProviderName()).getProviderUrl()
						+ " " + request.getJndiName() + " " + request.getMethodName();
				Tracer.SpanBuilder spanBuilder = tracer.buildSpan(spanText);
				spanBuilder.withTag(Tags.COMPONENT.getKey(), "ejb-client");
				span = spanBuilder.startActive(true);
			}

			if (ejbConfig.getProperties(request.getProviderName()).isLoggingEnabled()) {
				logRequest(request);
			}

			Object proceed = joinPoint.proceed();

			if (ejbConfig.getProperties(request.getProviderName()).isLoggingEnabled()) {
				logResponse(proceed);
			}
			return proceed;
		} finally {
			try {
				if (span != null) {
					span.close();
				}
			} catch (Exception ex) {
				log.error("Exception while deactivating the span" + ex.getMessage());
			}
		}
	}

	private String convertObjectToString(Object obj) {
		String str = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			str = mapper.writeValueAsString(obj);

		} catch (Exception ex) {
			log.warn("Exception while converting object into string" + ex);
		}
		return str;
	}

	/**
	 * Logs Request of out-bound call
	 * 
	 * @param request
	 * @param body
	 * @throws UnsupportedEncodingException
	 */
	private void logRequest(EJBRequest request) {

		final StringBuilder strBuffer = new StringBuilder();
		try {
			printRequestLine(strBuffer, request);
			printRequestHeaders(strBuffer, request.getProviderName());
			printEntity(strBuffer, request);
		} catch (Exception ex) {
			log.error("Failed to parse body", ex);
		} finally {
			log.info(strBuffer.toString());
		}

	}

	/**
	 * @param stringBuilder
	 * @return
	 */
	private StringBuilder prefixId(StringBuilder stringBuilder) {
		return stringBuilder;
	}

	/**
	 * @param strBuffer
	 * @param request
	 */
	private void printRequestLine(StringBuilder strBuffer, EJBRequest request) {
		prefixId(strBuffer).append(NOTIFICATION_PREFIX).append("EJB Client request").append('\n');
		prefixId(strBuffer).append(REQUEST_PREFIX)
				.append(ejbConfig.getProperties(request.getProviderName()).getProviderUrl()).append(" ")
				.append(request.getJndiName()).append(" ").append(request.getMethodName()).append('\n');
	}

	/**
	 * @param strBuffer
	 * @param headers
	 */
	private void printRequestHeaders(StringBuilder strBuffer, String providerName) {

		for (Map.Entry<String, String> e : ejbConfig.getProperties(providerName).getDefaultHeaders().entrySet()) {

			prefixId(strBuffer).append(REQUEST_PREFIX).append(e.getKey()).append(": ").append(e.getValue())
					.append('\n');

		}
		prefixId(strBuffer).append(REQUEST_PREFIX).append('\n');
	}

	/**
	 * @param strBuffer
	 * @param entity
	 * @throws IOException
	 */
	private void printEntity(StringBuilder strBuffer, EJBRequest request) {
		if (ejbConfig.getProperties(request.getProviderName()).isLoggingEnabled()) {
			strBuffer.append(convertObjectToString(request.getMethodInputs())).append("\n");
		}
	}

	/**
	 * Logs Response to out bound call
	 * 
	 * @param response
	 * @throws IOException
	 */
	private void logResponse(Object response) {
		final StringBuilder strBuffer = new StringBuilder();
		try {
			prefixId(strBuffer).append(NOTIFICATION_PREFIX).append("EJB Client response").append('\n');
			prefixId(strBuffer).append(RESPONSE_PREFIX);
			strBuffer.append(convertObjectToString(response)).append("\n");

		} catch (Exception e) {
			log.error("Failed to parse body", e);
		} finally {
			log.info(strBuffer.toString());
		}

	}

}
