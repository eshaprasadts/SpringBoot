package com.att.idp.ejb.client.config;

import java.io.Serializable;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import amdocs.security.APILogin;
import amdocs.uams.UamsSystem;
import amdocs.uams.login.UamsLoginContext;
import amdocs.uams.login.direct.UamsDirectLoginContext;
import amdocs.uamsimpl.client.login.direct.DirectLoginServiceWrapper;

/**
 * Template for EJB properties.
 */
public class EJBClientProperties implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9133007286170808653L;

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(EJBClientProperties.class);

	/** The initial context factory. */
	private String initialContextFactory;

	/** The provider url. */
	private String providerUrl;

	/** The security authentication. */
	private String securityAuthentication;

	/** The security principal. */
	private String securityPrincipal;

	/** The security credentials. */
	private String securityCredentials;

	/** The user. */
	private String user;

	/** The password. */
	private String password;

	/** The application. */
	private String application;

	/** The ticket. */
	private String ticket;
	
	private String clusterId;
	
	private String marketRoutingEnabled;

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	/** The default headers. */
	private Map<String, String> defaultHeaders;
	
	/** The logging enabled. */
	private boolean loggingEnabled;

	private String uamsSvcName;

	private String environment;
	
	private String jaasConfig;
	
	/**
	 * Gets the initial context factory.
	 *
	 * @return the initial context factory
	 */
	public String getInitialContextFactory() {
		return initialContextFactory;
	}

	/**
	 * Sets the initial context factory.
	 *
	 * @param initialContextFactory
	 *            the new initial context factory
	 */
	public void setInitialContextFactory(String initialContextFactory) {
		this.initialContextFactory = initialContextFactory;
	}

	/**
	 * Gets the provider url.
	 *
	 * @return the provider url
	 */
	public String getProviderUrl() {
		return providerUrl;
	}

	/**
	 * Sets the provider url.
	 *
	 * @param providerUrl
	 *            the new provider url
	 */
	public void setProviderUrl(String providerUrl) {
		this.providerUrl = providerUrl;
	}

	/**
	 * Gets the security authentication.
	 *
	 * @return the security authentication
	 */
	public String getSecurityAuthentication() {
		return securityAuthentication != null ? securityAuthentication : "";
	}

	/**
	 * Sets the security authentication.
	 *
	 * @param securityAuthentication
	 *            the new security authentication
	 */
	public void setSecurityAuthentication(String securityAuthentication) {
		this.securityAuthentication = securityAuthentication;
	}

	/**
	 * Gets the security principal.
	 *
	 * @return the security principal
	 */
	public String getSecurityPrincipal() {
		return securityPrincipal != null ? securityPrincipal : "";
	}

	/**
	 * Sets the security principal.
	 *
	 * @param securityPrincipal
	 *            the new security principal
	 */
	public void setSecurityPrincipal(String securityPrincipal) {
		this.securityPrincipal = securityPrincipal;
	}

	/**
	 * Gets the security credentials.
	 *
	 * @return the security credentials
	 */
	public String getSecurityCredentials() {
		return securityCredentials != null ? securityCredentials : "";
	}

	/**
	 * Sets the security credentials.
	 *
	 * @param securityCredentials
	 *            the new security credentials
	 */
	public void setSecurityCredentials(String securityCredentials) {
		this.securityCredentials = securityCredentials;
	}

	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * Sets the user.
	 *
	 * @param user
	 *            the new user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password
	 *            the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the application.
	 *
	 * @return the application
	 */
	public String getApplication() {
		return application;
	}

	/**
	 * Sets the application.
	 *
	 * @param application
	 *            the new application
	 */
	public void setApplication(String application) {
		this.application = application;
	}

	/**
	 * Checks if is need ticket.
	 *
	 * @return true, if is need ticket
	 */
	public boolean isNeedTicket() {
		return (user != null && password != null && application != null);
	}

	/**
	 * Gets the ticket.
	 *
	 * @return the ticket
	 */
	public String getTicket() {
		if (ticket == null) {
			try {
				if (!StringUtils.isEmpty(uamsSvcName) && !StringUtils.isEmpty(environment)) {
					ticket = getEnablerTicket();
				} else {
					ticket = APILogin.login(user, password, application);
				}
			} catch (Exception e) {
				log.error("error creating login ticket", e);
			}
		}
		if (log.isDebugEnabled())
			log.debug("ticket=" + ticket);
		return ticket;
	}
	
	public String getEnablerTicket() {
		DirectLoginServiceWrapper wrapper;
		try {
			log.debug("getEnablerTicket uamsSvcName={} environment={}",uamsSvcName,environment);
			wrapper = (DirectLoginServiceWrapper) UamsSystem.getService(null, uamsSvcName);
			UamsLoginContext loginCtx = wrapper.login(user, password, application, environment);
			int status = loginCtx.getStatus();
			if (status==1) {
				return loginCtx.getTicket();
			} else {
				log.error("login failed. usrStatus={}, errorMessage={}",loginCtx.getUserStatus(),((UamsDirectLoginContext) loginCtx).getErrorMessage());
			}			
		} catch (Exception e) {
			log.error("Enabler DirectLoginServiceWrapper.login failed",e);
		}
		return null;
	}

	/**
	 * Reset ticket.
	 */
	public void resetTicket() {
		ticket = null;
	}

	/**
	 * using provider URL as key, override to specify different key.
	 *
	 * @return the prop key
	 */
	public String getPropKey() {
		return getProviderUrl();
	}

	/**
	 * Gets the default headers.
	 *
	 * @return the default headers
	 */
	public Map<String, String> getDefaultHeaders() {
		return defaultHeaders;
	}

	/**
	 * Sets the default headers.
	 *
	 * @param defaultHeaders the default headers
	 */
	public void setDefaultHeaders(Map<String, String> defaultHeaders) {
		this.defaultHeaders = defaultHeaders;
	}

	/**
	 * Checks if is logging enabled.
	 *
	 * @return true, if is logging enabled
	 */
	public boolean isLoggingEnabled() {
		return loggingEnabled;
	}

	/**
	 * Sets the logging enabled.
	 *
	 * @param loggingEnabled the new logging enabled
	 */
	public void setLoggingEnabled(boolean loggingEnabled) {
		this.loggingEnabled = loggingEnabled;
	}

	public String getClusterId() {
		return clusterId;
	}

	public void setClusterId(String clusterId) {
		this.clusterId = clusterId;
	}

	public String getMarketRoutingEnabled() {
		return marketRoutingEnabled;
	}

	public void setMarketRoutingEnabled(String marketRoutingEnabled) {
		this.marketRoutingEnabled = marketRoutingEnabled;
	}

	public String getUamsSvcName() {
		return uamsSvcName;
	}

	public void setUamsSvcName(String uamsSvcName) {
		this.uamsSvcName = uamsSvcName;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getJaasConfig() {
		return jaasConfig;
	}

	public void setJaasConfig(String jaasConfig) {
		this.jaasConfig = jaasConfig;
	}
}
