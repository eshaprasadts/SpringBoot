/*
 * 
 */
package com.att.idp.ejb.client;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.ejb.client.config.EJBClientInterceptor;

/**
 * A factory for creating EJBBean objects.
 */
@Component
public class EJBClient {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(EJBClient.class);

	/** The home factory. */
	@Autowired
	EJBHomeFactory homeFactory;

	/**
	 * Reset all EJB homes.
	 */
	public void resetAllEJBHomes() {
		homeFactory.resetAllEJBHomes();
	}

	/**
	 * Reset EJB home for specific provider and jdniName given
	 * will reset only one home instance
	 * @param providerName
	 *            the providerName
	 * @param jndiName
	 *            the jndi name
	 */
	public boolean resetEJBHome(String providerName, String jndiName) {
		return (homeFactory.resetEJBHome(providerName, jndiName));
	}
	
	/**
	 * Reset All EJB home instances containing the string given
	 * @param str
	 */
	public void resetEJBHomeBy(String str) {
		homeFactory.resetEJBHomeBy(str);
	}

	/**
	 * Gets the EJB bean.
	 *
	 * @param providerName            the providerName
	 * @param jndiName            the jndi name
	 * @return the EJB bean
	 * @throws NamingException             the naming exception
	 * @throws NoSuchMethodException             the no such method exception
	 * @throws IllegalAccessException             the illegal access exception
	 * @throws InvocationTargetException             the invocation target exception
	 * @throws IllegalArgumentException             the illegal argument exception
	 */
	public Object getEJBBean(String providerName, String jndiName)
			throws NamingException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		Object home = homeFactory.getEJBHome(providerName, jndiName);
		Method m = home.getClass().getDeclaredMethod("create", (Class[]) new Class[0]);
		if (log.isDebugEnabled())
			log.debug("getting EJB bean (" + providerName + ") for " + jndiName);
		return m.invoke(home, (Object[]) new Object[0]);		
	}

	/**
	 * Gets the param classes.
	 *
	 * @param args the args
	 * @return the param classes
	 */
	private Class<?>[] getParamClasses(Object[] args) {
		Class<?>[] paramClasses;
		if (args != null && args.length > 0) {
			paramClasses = new Class[args.length];
			for (int i = 0; i < args.length; i++) {
				paramClasses[i] = args[i].getClass();
			}
		} else {
			paramClasses = new Class[] {};
		}
		return paramClasses;
	}

	/**
	 * Invokes the EJB.
	 *
	 * @param request the request
	 * @return the object
	 * @throws NamingException 
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws NoSuchMethodException 
	 * @throws Exception the exception
	 */
	@EJBClientInterceptor
	public Object invoke(EJBRequest request) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, NamingException {
		validateRequest(request);
		Object bean=request.getRemoteInterface();
		if (bean==null) {
			bean = getEJBBean(request.getProviderName(), request.getJndiName());
		}
		
		Class<?>[] paramTypes=request.getMethodInputTypes();
		if (paramTypes==null)
			paramTypes=getParamClasses(request.getMethodInputs());
		Method m = bean.getClass().getDeclaredMethod(request.getMethodName(),paramTypes);
		Object o=null;
		try {
			o=m.invoke(bean, request.getMethodInputs());
		} catch (Exception e) {
			homeFactory.createContext(request.getProviderName());
			o=m.invoke(bean, request.getMethodInputs());
		}
		return o;
	}

	/**
	 * Validate request.
	 *
	 * @param request the request
	 */
	private void validateRequest(EJBRequest request) {

		if (request.getJndiName() == null) {
			throw new NullPointerException("jndiName is missing in request");
		}
		if (request.getProviderName() == null) {
			throw new NullPointerException("providerName is missing in request");
		}
		if (request.getMethodName() == null) {
			throw new NullPointerException("methodName is missing in request");
		}

	}

}
