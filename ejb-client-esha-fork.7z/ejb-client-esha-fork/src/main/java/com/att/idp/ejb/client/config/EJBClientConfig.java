package com.att.idp.ejb.client.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * This class holds config specific to ejb client for an application.
 */
@Component
@ConfigurationProperties(prefix = "ejbclient")
public class EJBClientConfig {
	
	/**
	 * Auto populated by spring by convention
	 * Properties prefixed with 'ejbclient.ejb' will be loaded in this map
	 */
	private Map<String, EJBClientProperties> ejb;

	/**
	 * Gets the properties.
	 *
	 * @param providerName the provider name
	 * @return the properties
	 */
	public EJBClientProperties getProperties(String providerName) {
		
		if(providerName == null) {
			throw new IllegalArgumentException("providerName can not be null");
		}

		EJBClientProperties ejbProps = null;			
		EJBClientProperties defaultProps = null;
		
		if(ejb != null) {				
			ejbProps = ejb.get(providerName);			
			defaultProps = ejb.get("default");				
		}
		
		//if no specific AND default config, return null
		if(ejbProps == null && defaultProps ==null) {
			return null;
		}
		
		//if no default, return specific config (NotNull)
		if(defaultProps == null) {
			return ejbProps;
		}
		
		//initialize with empty if apiProps is null, as it may get populated from defaultProps
		ejbProps = (ejbProps != null) ? ejbProps : new EJBClientProperties();
		//merge with default if specific config is missing
		ejbProps.setApplication(ejbProps.getApplication()==null?defaultProps.getApplication():ejbProps.getApplication());
		ejbProps.setClusterId(ejbProps.getClusterId()==null?defaultProps.getClusterId():ejbProps.getClusterId());
		ejbProps.setDefaultHeaders(ejbProps.getDefaultHeaders()==null?defaultProps.getDefaultHeaders():ejbProps.getDefaultHeaders());
		ejbProps.setInitialContextFactory(ejbProps.getInitialContextFactory()==null?defaultProps.getInitialContextFactory():ejbProps.getInitialContextFactory());
		ejbProps.setMarketRoutingEnabled(ejbProps.getMarketRoutingEnabled()==null?defaultProps.getMarketRoutingEnabled():ejbProps.getMarketRoutingEnabled());
		ejbProps.setPassword(ejbProps.getPassword()==null?defaultProps.getPassword():ejbProps.getPassword());
		ejbProps.setProviderUrl(ejbProps.getProviderUrl()==null?defaultProps.getProviderUrl():ejbProps.getProviderUrl());
		ejbProps.setUser(ejbProps.getUser()==null?defaultProps.getUser():ejbProps.getUser());
		ejbProps.setSecurityAuthentication(ejbProps.getSecurityAuthentication()==null?defaultProps.getSecurityAuthentication():ejbProps.getSecurityAuthentication());
		ejbProps.setSecurityCredentials(ejbProps.getSecurityCredentials()==null?defaultProps.getSecurityCredentials():ejbProps.getSecurityCredentials());
		ejbProps.setUamsSvcName(ejbProps.getUamsSvcName()==null?defaultProps.getUamsSvcName():ejbProps.getUamsSvcName());
		ejbProps.setEnvironment(ejbProps.getEnvironment()==null?defaultProps.getEnvironment():ejbProps.getEnvironment());
		ejbProps.setJaasConfig(ejbProps.getJaasConfig()==null?defaultProps.getJaasConfig():ejbProps.getJaasConfig());
		return ejbProps;
	}

	/**
	 * Gets the ejb.
	 *
	 * @return the ejb
	 */
	public Map<String, EJBClientProperties> getEjb() {
		return ejb;
	}

	/**
	 * Sets the ejb.
	 *
	 * @param ejb the ejb
	 */
	public void setEjb(Map<String, EJBClientProperties> ejb) {
		this.ejb = ejb;
	}

}
