package com.att.idp.ejb.client;

/**
 * The Class EJBRequest.
 */
public class EJBRequest {

	/** The app name. */
	private String providerName;
	
	/** The jndi name. */
	private String jndiName;
	
	/** The method name. */
	private String methodName;
	
	/** The method inputs. */
	private Object[] methodInputs;
	
	/** The method input types. */
	private Class<?>[] methodInputTypes;
	
	/** The remote interface. */
	private Object remoteInterface;

	/**
	 * Gets the app name.
	 *
	 * @return the app name
	 */
	public String getProviderName() {
		return providerName;
	}

	/**
	 * Sets the app name.
	 *
	 * @param providerName the new app name
	 */
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	/**
	 * Gets the jndi name.
	 *
	 * @return the jndi name
	 */
	public String getJndiName() {
		return jndiName;
	}

	/**
	 * Sets the jndi name.
	 *
	 * @param jndiName the new jndi name
	 */
	public void setJndiName(String jndiName) {
		this.jndiName = jndiName;
	}

	/**
	 * Gets the method name.
	 *
	 * @return the method name
	 */
	public String getMethodName() {
		return methodName;
	}

	/**
	 * Sets the method name.
	 *
	 * @param methodName the new method name
	 */
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	/**
	 * Gets the method inputs.
	 *
	 * @return the method inputs
	 */
	public Object[] getMethodInputs() {
		return methodInputs;
	}

	/**
	 * Sets the method inputs.
	 *
	 * @param methodInputs the new method inputs
	 */
	public void setMethodInputs(Object[] methodInputs) {
		this.methodInputs = methodInputs;
	}

	/**
	 * Gets the remote interface.
	 *
	 * @return the remote interface
	 */
	public Object getRemoteInterface() {
		return remoteInterface;
	}

	/**
	 * Sets the remote interface.
	 *
	 * @param remoteInterface the new remote interface
	 */
	public void setRemoteInterface(Object remoteInterface) {
		this.remoteInterface = remoteInterface;
	}

	/**
	 * Gets the method input types.
	 *
	 * @return the method input types
	 */
	public Class<?>[] getMethodInputTypes() {
		return methodInputTypes;
	}

	/**
	 * Sets the method input types.
	 *
	 * @param methodInputTypes the new method input types
	 */
	public void setMethodInputTypes(Class<?>[] methodInputTypes) {
		this.methodInputTypes = methodInputTypes;
	}

}
