/**
 * 
 */
package com.att.idp.ejb.client.config;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The Interface EJBClientInterceptor.
 *
 * @author av206a
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface EJBClientInterceptor {

}
