package com.att.idp.ejb.client;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

import weblogic.security.auth.callback.URLCallback;

public class URLCallbackHandler implements CallbackHandler {
	private String url;
	private String username;
	private byte[] password;

	public URLCallbackHandler(String arg0, String arg1) {
		this(arg0, arg1.getBytes());
	}

	public URLCallbackHandler(String arg0, byte[] arg1) {
		this.url = null;
		this.username = arg0;
		this.password = arg1;
	}

	public URLCallbackHandler(String arg0, String arg1, String arg2) {
		this(arg0, arg1.getBytes(), arg2);
	}

	public URLCallbackHandler(String arg0, byte[] arg1, String arg2) {
		this.url = arg2;
		this.username = arg0;
		this.password = arg1;
	}

	public void handle(Callback[] arg0) throws UnsupportedCallbackException {
		for (int arg1 = 0; arg1 < arg0.length; ++arg1) {
			if (arg0[arg1] instanceof NameCallback) {
				NameCallback arg2 = (NameCallback) arg0[arg1];
				arg2.setName(this.username);
			} else if (arg0[arg1] instanceof PasswordCallback) {
				PasswordCallback arg3 = (PasswordCallback) arg0[arg1];
				if (this.password != null) {
					arg3.setPassword((new String(this.password)).toCharArray());
				}
			} else {
				if (!(arg0[arg1] instanceof URLCallback)) {
					throw new UnsupportedCallbackException(arg0[arg1], "Unrecognized Callback");
				}

				URLCallback arg4 = (URLCallback) arg0[arg1];
				if (this.url != null) {
					arg4.setURL(this.url);
				} else {
					arg4.setURL(arg4.getdefaultURL());
				}
			}
		}

	}
}