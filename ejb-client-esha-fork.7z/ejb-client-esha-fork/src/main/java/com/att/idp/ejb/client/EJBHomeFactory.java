package com.att.idp.ejb.client;

import java.security.PrivilegedAction;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.idp.ejb.client.config.EJBClientConfig;
import com.att.idp.ejb.client.config.EJBClientProperties;

import weblogic.security.Security;

/**
 * A factory for creating EJBHome objects.
 *
 * @author av206a
 */
@Component
public class EJBHomeFactory {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(EJBHomeFactory.class);

	/** The ejb config. */
	@Autowired
	private EJBClientConfig ejbConfig;

	/** the home map. */
	Map<String, Object> homeMap = new ConcurrentHashMap<>();

	/**
	 * Gets the environment.
	 *
	 * @param prop
	 *            the prop
	 * @return the environment
	 */
	private Properties getEnvironment(EJBClientProperties prop) {
		Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, prop.getInitialContextFactory());
		env.put(Context.PROVIDER_URL, prop.getProviderUrl());
		env.put(Context.SECURITY_AUTHENTICATION, prop.getSecurityAuthentication());
		env.put(Context.SECURITY_PRINCIPAL, prop.isNeedTicket() ? prop.getTicket() : prop.getSecurityPrincipal());
		env.put(Context.SECURITY_CREDENTIALS, prop.getSecurityCredentials());
		return env;
	}
	
	Context createContext(String providerName) throws NamingException {
		return new InitialContext(getEnvironment(ejbConfig.getProperties(providerName)));
	}
	
	private void createHome(String key, String providerName,String jndiName) throws NamingException {
		Context ctx=null;
		try {
			ctx = createContext(providerName);					
			Object home = ctx.lookup(jndiName);
			homeMap.put(key, home);
			if (log.isDebugEnabled())
				log.debug("new home, saved key={}",key);
		} finally {
			/** see weblogic CR307050 
			if (ctx!=null) {
				ctx.close();
			}
			**/
		}
	}
	
	private Subject getSubject(EJBClientProperties ejb) {
		Subject subject=null;
		try {
			LoginContext loginContext = new LoginContext(ejb.getJaasConfig(), new URLCallbackHandler(
					ejb.isNeedTicket() ? ejb.getTicket() : ejb.getSecurityPrincipal(), 
					ejb.getSecurityCredentials().getBytes(), 
					ejb.getProviderUrl()));
			loginContext.login();
			subject = loginContext.getSubject();
		} catch (LoginException le) {
			log.error("error jaas login",le);
		}
		return subject;
	}

	/**
	 * return EJB home (not using Spring framework).
	 *
	 * @param providerName the provider name
	 * @param jndiName            the jndi name
	 * @return the EJB home
	 * @throws NamingException             the naming exception
	 */
	public Object getEJBHome(String providerName, String jndiName) throws NamingException {
		EJBClientProperties ejb = ejbConfig.getProperties(providerName);
		String key = providerName + "_" + jndiName + "_" + ejb.getPropKey();
		if (log.isDebugEnabled())
			log.debug("getEJBHome ::key=" + key);
		if (homeMap.get(key) == null) {
			if (!StringUtils.isEmpty(ejb.getJaasConfig())) {
				Security.runAs(getSubject(ejb),new PrivilegedAction<Object>() {
					public Object run() {
						try {
							createHome(key, providerName, jndiName);
						} catch (NamingException e) {
							log.error("error creating home",e);
						}
						return null;
					}
				}); 
			} else {
				createHome(key, providerName, jndiName);
			}
		}
		return homeMap.get(key);
	}

	/**
	 * Reset all EJB homes.
	 */
	public void resetAllEJBHomes() {
		homeMap = new ConcurrentHashMap<>();
		if (log.isDebugEnabled())
			log.debug("EJB home map resetted");
	}

	/**
	 * Reset EJB home for specific provider and jdniName given
	 * will reset only one home instance
	 * @param providerName the provider name
	 * @param jndiName            the jndi name
	 */
	public boolean resetEJBHome(String providerName, String jndiName) {
		EJBClientProperties ejb = ejbConfig.getProperties(providerName);
		String key = providerName + "_" + jndiName + "_" + ejb.getPropKey();
		Object o=homeMap.remove(key);
		if (log.isDebugEnabled())
			log.debug("resetted EJB home key=" + key);
		return (o!=null);
	}
	
	/**
	 * Reset All EJB home instances containing the string given
	 * @param str
	 */
	public void resetEJBHomeBy(String str) {
		homeMap.entrySet().removeIf(entry -> entry.getKey().contains(str));
	}
}