package com.att.idp.http.client.config;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import com.att.idp.http.client.ApiLoggingInterceptor;
import com.att.idp.http.client.DefaultHeadersInterceptor;
import com.att.idp.http.client.DynamicBasicAuthInterceptor;
import com.att.idp.logging.client.RestApiLogger;

import io.opentracing.Tracer;
import io.opentracing.contrib.spring.web.client.TracingRestTemplateInterceptor;

/**
 * Factory to create customized RestTemplate instances.
 */
@Component
public class RestTemplateBeanFactory implements FactoryBean<RestTemplate> {

	// TODO: To be refractored to remove dependency on tracer in this class
	@Autowired
	Tracer tracer;

	@Autowired
	private RestTemplateBuilder builder;

	@Autowired
	private RestClientConfig restClientProps;

	/**
	 * As a part of platform we want to recommend the usage of parameterized call to
	 * get the Rest Template Object so that, the instances returned will have API
	 * specific configurations
	 */
	@Override
	public RestTemplate getObject() throws Exception {
		return builder.build();
	}

	/**
	 * Takes in the name of API for which the client is needed and sets the
	 * configurations specific to that API for each service
	 * 
	 * @param apiName
	 * @return
	 * @throws Exception
	 */
	public RestTemplate getObject(String apiName) throws Exception {

		// builder returns new instance for each additional* call,
		// Make sure to chain the calls
		if (apiName == null) {
			throw new NullPointerException("apiName");
		}	
		RestApiProperties apiProps = restClientProps.getProperties(apiName);
		
		//Sequence of Interceptor is critical due to dependency on information.
		// 1. TracingRestTemplateInterceptor
		// 2. BasicAuthInterceptor  (depends on TracingRestTemplateInterceptor)
		// 3. DefaultHeaderInterceptor (no dependency)
		// 4. ApiLoggingInterceptor	   (dependency due to info expected in logged message)
		RestTemplateBuilder bldr = tracingInterceptor(builder, apiProps);
		bldr = basicAuthInterceptor(bldr, apiProps);
		bldr = defaultHeadersInterceptor(bldr, apiProps);
		bldr = loggingInterceptor(bldr, apiProps);
		
		RestTemplate restTemplate = bldr.build();	
		// Setting the BufferingClientHttpRequestFactory in to Rest Template so that we
		// can read the request's body into memory, thus allowing for multiple
		// invocations of getBody().		
		HttpComponentsClientHttpRequestFactory	httpClientFactory = new HttpComponentsClientHttpRequestFactory();
		httpClientFactory.setConnectTimeout(apiProps.getConnectTimeout());
		httpClientFactory.setReadTimeout(apiProps.getReadTimeout());

		restTemplate.setRequestFactory(new BufferingClientHttpRequestFactory(httpClientFactory));
		restTemplate.setErrorHandler(new DefaultResponseErrorHandler());
	    //restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		return restTemplate;
	}
	
	private RestTemplateBuilder tracingInterceptor(RestTemplateBuilder bldr, RestApiProperties apiProps) {
		return bldr.additionalInterceptors(new TracingRestTemplateInterceptor(tracer));
	}

	private RestTemplateBuilder basicAuthInterceptor(RestTemplateBuilder bldr, RestApiProperties apiProps) {
		if (apiProps != null && 
				("true".equalsIgnoreCase(apiProps.getBasicAuth()) || "true".equalsIgnoreCase(apiProps.getUserTypesBasicAuth()))
			) {			
			bldr = bldr.additionalInterceptors(new DynamicBasicAuthInterceptor(apiProps));
		}
		return bldr;
	}
	
	private RestTemplateBuilder defaultHeadersInterceptor(RestTemplateBuilder bldr, RestApiProperties apiProps) {
		if (apiProps != null && !apiProps.getDefaultHeaders().isEmpty()) {
			bldr = bldr.additionalInterceptors(new DefaultHeadersInterceptor(apiProps.getDefaultHeaders()));
		}
		return bldr;
	}

	private RestTemplateBuilder loggingInterceptor(RestTemplateBuilder builder, RestApiProperties apiProps) {
		return builder.additionalInterceptors(new ApiLoggingInterceptor(new RestApiLogger(apiProps.getLogLevel())));
	}

	@Override
	public Class<?> getObjectType() {
		return RestTemplate.class;
	}

	@Override
	public boolean isSingleton() {
		return false;
	}

}