package com.att.idp.http.client.config;

import java.util.HashMap;
import java.util.Map;

import com.att.idp.logging.LogLevel;

/**
 * Template for Rest API configuration Properties
 *
 */
public class RestApiProperties {

	private String username;

	private String password;
	
	private String basicAuth;
	
	private String userTypesBasicAuth;

	private Map<String, UserType> userTypes;
	
	private Map<String, String> defaultHeaders;
	
	private LogLevel logLevel;
	
	private int connectTimeout;

	private int readTimeout;	
	
	public RestApiProperties() {
		super();
		this.defaultHeaders = new HashMap<>();
		this.userTypes = new HashMap<>();
	}
	
	public LogLevel getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(LogLevel logLevel) {
		this.logLevel = logLevel;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getBasicAuth() {
		return basicAuth;
	}

	public void setBasicAuth(String basicAuth) {
		this.basicAuth = basicAuth;
	}
	

	public String getUserTypesBasicAuth() {
		return userTypesBasicAuth;
	}

	public void setUserTypesBasicAuth(String userTypesBasicAuth) {
		this.userTypesBasicAuth = userTypesBasicAuth;
	}

	public Map<String, String> getDefaultHeaders() {
		return defaultHeaders;
	}

	public Map<String, UserType> getUserTypes() {
		return userTypes;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}
}



