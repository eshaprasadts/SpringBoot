package com.att.idp.http.client;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.AsyncClientHttpRequestExecution;
import org.springframework.http.client.AsyncClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.att.idp.logging.client.RestApiLogger;

import io.opentracing.util.GlobalTracer;

/**
 * 
 * TODO: enhance to match Request/Response Log structure
 *
 */

/**
 * @author ep887j
 *
 *         ApiLoggingInterceptor is an implementation of
 *         ClientHttpRequestInterceptor used to intercept logging feature as a
 *         part of calling class in IDP platform level it is added into the Rest
 *         Template it self so that who ever uses IDSP/IDP layer to create a
 *         micro-service would get out bound request and response logging
 *         feature buit in. But user/micro-service can disable logging for that
 *         API by setting the properties of LoggingProperties inner class
 */

public class ApiLoggingInterceptor implements ClientHttpRequestInterceptor, AsyncClientHttpRequestInterceptor {
	
	private static final String OPENTRACING_TRACE_ID = "idp-trace-id";
	
	private static final Logger logger = LoggerFactory.getLogger(ApiLoggingInterceptor.class);
	
	private RestApiLogger restApiLogger;
		
	public ApiLoggingInterceptor(RestApiLogger restApiLogger) {
		super();
		this.restApiLogger = restApiLogger;
	}
	/**
	 * Over rides the ClientHttpRequestInterceptor's intercept method by adding the
	 * Request logs and Response logs (after executing the out bound rest service
	 * call)
	 */
	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		
		ClientHttpResponse response = null;
		String currentTraceId = MDC.get(OPENTRACING_TRACE_ID);
		try {			
			MDC.put(OPENTRACING_TRACE_ID, GlobalTracer.get().activeSpan().toString());
			
			restApiLogger.logRequest(request, body);
			
			long startTime = System.currentTimeMillis();
			response = execution.execute(request, body);
			long endTime = System.currentTimeMillis();
			
			restApiLogger.logResponse(response, endTime - startTime);
		} 
		finally {
			MDC.put(OPENTRACING_TRACE_ID, currentTraceId);
		}

		return response;	
	}
	
	
	@Override
	public ListenableFuture<ClientHttpResponse> intercept(HttpRequest request, byte[] body,
			AsyncClientHttpRequestExecution execution) throws IOException {

		ListenableFuture<ClientHttpResponse> response = null;
		String parentTraceId = MDC.get(OPENTRACING_TRACE_ID);
		String currentTraceId = GlobalTracer.get().activeSpan().toString();
		
		try {
			//switch the traceid for logging purpose
			MDC.put(OPENTRACING_TRACE_ID, currentTraceId);
			restApiLogger.logRequest(request, body);
		} 
		finally {
			//revert to parentTraceId
			MDC.put(OPENTRACING_TRACE_ID, parentTraceId);
		}
			
		long startTime = System.currentTimeMillis();
		response = execution.executeAsync(request, body);
		
		response.addCallback(new ListenableFutureCallback<ClientHttpResponse>() {
			
			@Override
			public void onSuccess(ClientHttpResponse response) {
				try {
					long endTime = System.currentTimeMillis();					
					MDC.put(OPENTRACING_TRACE_ID, currentTraceId);					
					restApiLogger.logResponse(response, endTime - startTime);
				} catch (IOException e) {
					logger.error("Error occurred while logging response ", e);
				} finally {
					MDC.remove(OPENTRACING_TRACE_ID);
				}				
			}

			@Override
			public void onFailure(Throwable t) {					
				logger.error("Error occurred in invoking REST api " + request.getMethod() +  " " + request.getURI(), t);
			}				
		});
		
		return response;
	}

}
