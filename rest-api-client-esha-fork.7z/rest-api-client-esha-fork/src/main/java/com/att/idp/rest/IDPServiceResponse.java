package com.att.idp.rest;

/*
 * Default class to read IDP services response
 */
public class IDPServiceResponse<T> {

	public IDPServiceResponse() {

	}

	T content = null;

	/**
	 * This method gets the content of the User Response
	 * 
	 * @return content of the user Response
	 * 
	 */
	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}

}