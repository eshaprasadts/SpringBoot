package com.att.idp.http.client.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.att.idp.logging.LogLevel;

/**
 * This class holds config specific to restapiclients in an application
 * 
 */
@Component
@ConfigurationProperties(prefix = "apiclient")
public class RestClientConfig {
	
	/**
	 * Auto populated by spring by convention
	 * Properties prefixed with 'apiclient.rest' will be loaded in this map
	 */
	private Map<String, RestApiProperties> rest;

	public RestApiProperties getProperties(String api) {
		
		if(api == null) {
			throw new IllegalArgumentException("api can not be null");
		}

		RestApiProperties apiProps = null;			
		RestApiProperties defaultProps = null;
		
		if(rest != null) {				
			apiProps = rest.get(api);			
			defaultProps = rest.get("default");				
		}
		
		//if no specific AND default config, return null
		if(apiProps == null && defaultProps ==null) {
			return null;
		}
		
		//if no default, return specific config (NotNull)
		if(defaultProps == null) {
			return apiProps;
		}
		
		//initialize with empty if apiProps is null, as it may get populated from defaultProps
		apiProps = (apiProps != null) ? apiProps : new RestApiProperties();
		
		//merge with default if specific config is missing
		//apiProps.setBasicAuth((apiProps.getBasicAuth() == null ? defaultProps.getBasicAuth(): apiProps.getBasicAuth()));
		apiProps.setUsername((apiProps.getUsername() == null ? defaultProps.getUsername(): apiProps.getUsername()));
		apiProps.setPassword((apiProps.getPassword() ==null ? defaultProps.getPassword(): apiProps.getPassword()));
		
		apiProps.setConnectTimeout((apiProps.getConnectTimeout() == 0? defaultProps.getConnectTimeout(): apiProps.getConnectTimeout()));
		apiProps.setReadTimeout((apiProps.getReadTimeout() == 0? defaultProps.getReadTimeout(): apiProps.getReadTimeout()));
		
		defaultProps.setLogLevel(defaultProps.getLogLevel() != null? defaultProps.getLogLevel() : LogLevel.DEBUG);
		apiProps.setLogLevel(apiProps.getLogLevel() == null? defaultProps.getLogLevel(): apiProps.getLogLevel());
		
		Map<String, String> defaultHeaders = apiProps.getDefaultHeaders();						
		for(String key : defaultProps.getDefaultHeaders().keySet()) {
			defaultHeaders.putIfAbsent(key, defaultProps.getDefaultHeaders().get(key));
		}

		//apiProps.setUserTypesBasicAuth((apiProps.getUserTypesBasicAuth() == null ? defaultProps.getUserTypesBasicAuth(): apiProps.getUserTypesBasicAuth()));
		Map<String, UserType> apiRoles = apiProps.getUserTypes();						
		for(String key : defaultProps.getUserTypes().keySet()) {
			apiRoles.putIfAbsent(key, defaultProps.getUserTypes().get(key));
		}
		
		return apiProps;
	}

	public Map<String, RestApiProperties> getRest() {
		return rest;
	}

	public void setRest(Map<String, RestApiProperties> rest) {
		this.rest = rest;
	}

}
