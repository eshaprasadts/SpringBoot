package com.att.idp.logging.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import org.apache.log4j.MDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.MultiValueMap;

import com.att.idp.logging.LogLevel;


public final class RestApiLogger {

	private static final Logger logger = LoggerFactory.getLogger(RestApiLogger.class);

	/**
	 * LoggingProperties holds configurable properties for logging at the API level
	 * By default the logging feature and logging body will be enabled but it can be
	 * disabled at each API level by having a similar properties entry exampe :
	 * apiclient.rest.cpc.logging.bodyEnabled=false
	 */
	private LogLevel logLevel;

	public RestApiLogger(LogLevel logLevel) {
		super();
		this.logLevel = logLevel;
	}

	/**
	 * Logs Request of out-bound call
	 * 
	 * @param request
	 * @param body
	 * @throws UnsupportedEncodingException
	 */
	public void logRequest(HttpRequest request, byte[] body) throws UnsupportedEncodingException {		
		
		long startTime = System.nanoTime();
		
		final StringBuilder strBuffer = new StringBuilder();

		if (logger.isInfoEnabled()) {
			LogFormatter.printRequestLine(strBuffer, request.getMethod().toString(), request.getURI().toString());
			printRequestHeaders(strBuffer, request.getHeaders());
		}
		
		//only parse body for logging if DEBUG is enabled
		if (logger.isDebugEnabled() && this.logLevel.isDebugEnabled()) {
			try {
				LogFormatter.printEntity(strBuffer, body);
			} catch (IOException e) {
				logger.warn("Error Parsing Request Body ", e);
			}
		}
		
		if(logger.isDebugEnabled()) {
			logger.debug(strBuffer.toString());
		} else {
			logger.info(strBuffer.toString());
		}
		
		long endTime = System.nanoTime();
		long duration = (endTime - startTime);		
		recordLoggingOverhead(duration, "Request");
	}
	
	/**
	 * Logs Response to out bound call
	 * 
	 * @param response
	 * @param duration time taken to receieve a response from remote server
	 * @throws IOException
	 */
	public void logResponse(ClientHttpResponse response, long duration) throws IOException {
		
		
		long logStartTime = System.nanoTime();
		
		final StringBuilder strBuffer = new StringBuilder();
		if (logger.isInfoEnabled()) {
			LogFormatter.printResponseLine(strBuffer, response.getStatusCode().toString());
			printResponseHeaders(strBuffer, response.getHeaders());
		}

		//only parse body for logging if DEBUG is enabled
		if (logger.isDebugEnabled() && this.logLevel.isDebugEnabled()) {
			try {
				strBuffer.append(new String(inputStreamToString(response.getBody()))).append("\n");
			} catch (IOException e) {
				logger.warn("Error Parsing Request Body ", e);
			}
		}
		
		if(duration > -1) {
			MDC.put("duration", duration);
		}

		if(logger.isDebugEnabled()) {
			logger.debug(strBuffer.toString());
		} else {
			logger.info(strBuffer.toString());
		}
		
		MDC.remove("duration");
		
		long logEndTime = System.nanoTime();
		long loggingOverhead = (logEndTime - logStartTime);		
		recordLoggingOverhead(loggingOverhead, "Response");
	}

	/**
	 * Logs Response to out bound call
	 * 
	 * @param response
	 * @throws IOException
	 */
	public void logResponse(ClientHttpResponse response) throws IOException {
		//-1 indicates no duration available for logging
		logResponse(response, -1);
	}

	/**
	 * @param strBuffer
	 * @param entity
	 * @throws IOException
	 */
	public static void printEntity(StringBuilder strBuffer, byte[] entity) throws IOException {
		if (entity.length == 0)
			return;
		strBuffer.append(new String(entity)).append("\n");
	}

	public static String inputStreamToString(InputStream inputStream) throws IOException {
		StringBuilder builder = new StringBuilder();
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
		String line = bufferedReader.readLine();
		while (line != null) {
			builder.append(line);
			line = bufferedReader.readLine();
		}
		bufferedReader.close();
		return builder.toString();
	}

	/**
	 * @param strBuffer
	 * @param headers
	 */
	public void printRequestHeaders(StringBuilder strBuffer, MultiValueMap<String, String> headers) {
		for (Map.Entry<String, List<String>> e : headers.entrySet()) {
			String header = e.getKey();
			for (String value : e.getValue()) {
				LogFormatter.prefixId(strBuffer).append(LogFormatter.REQUEST_PREFIX).append(header).append(": ")
						.append(value).append('\n');
			}
		}
		LogFormatter.prefixId(strBuffer).append(LogFormatter.REQUEST_PREFIX).append('\n');
	}

	/**
	 * @param strBuffer
	 * @param headers
	 */
	public void printResponseHeaders(StringBuilder strBuffer, MultiValueMap<String, String> headers) {

		for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
			String header = entry.getKey();
			for (Object value : entry.getValue()) {
				LogFormatter.prefixId(strBuffer).append(LogFormatter.RESPONSE_PREFIX).append(header).append(": ")
						.append((value)).append('\n');
			}
		}
		LogFormatter.prefixId(strBuffer).append(LogFormatter.RESPONSE_PREFIX).append('\n');
	}
	
	/**
	 * @param duration time/overhead of logging
	 * @param type request/response
	 */
	private void recordLoggingOverhead(long duration, String type) {
		if(logger.isTraceEnabled()) {
			logger.trace(type + " Payload Logging overhead: " + duration + "ns");
		}
	}
}
