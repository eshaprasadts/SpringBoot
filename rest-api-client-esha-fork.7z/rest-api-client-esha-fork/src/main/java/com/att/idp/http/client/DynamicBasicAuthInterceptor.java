package com.att.idp.http.client;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.AsyncClientHttpRequestExecution;
import org.springframework.http.client.AsyncClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.Base64Utils;
import org.springframework.util.concurrent.ListenableFuture;

import com.att.idp.http.client.config.RestApiProperties;

public class DynamicBasicAuthInterceptor implements ClientHttpRequestInterceptor, AsyncClientHttpRequestInterceptor {
	
	private static final String userTypeHeaderKey = "idpctx-user-type";
	
	private static final Charset UTF_8 = Charset.forName("UTF-8");
	
	private RestApiProperties apiProps;
	
	public DynamicBasicAuthInterceptor(RestApiProperties apiProps) {
		super();
		this.apiProps = apiProps;
	}


	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {

		addBasicAuth(request);
		return execution.execute(request, body);
	}


	@Override
	public ListenableFuture<ClientHttpResponse> intercept(HttpRequest request, byte[] body,
			AsyncClientHttpRequestExecution execution) throws IOException {
		addBasicAuth(request);
		return execution.executeAsync(request, body);
	}
	
	private void addBasicAuth(HttpRequest request) {
		
		//static username & password has precedence over the dynamic usertype based BasicAuth
		if("true".equalsIgnoreCase(apiProps.getBasicAuth())) {
			
			String username = apiProps.getUsername();
			String password = apiProps.getPassword();
			
			if(username != null && !username.isEmpty()) {
				String token = Base64Utils.encodeToString((username + ":" + password).getBytes(UTF_8));
				request.getHeaders().add("Authorization", "Basic " + token);
			} 
			
		}
		
		if("true".equalsIgnoreCase(apiProps.getUserTypesBasicAuth())) {
		
			List<String> roles = request.getHeaders().get(userTypeHeaderKey);
			String role = (roles == null || roles.isEmpty()) ? null : roles.get(0);
			
			//Apply dynamic BasicAuth if userTypes configuration is present 
			if (apiProps.getUserTypes().get(role) != null) {
				String username = apiProps.getUserTypes().get(role).getUsername();
				String password = apiProps.getUserTypes().get(role).getPassword();
				
				String token = Base64Utils.encodeToString((username + ":" + password).getBytes(UTF_8));
				request.getHeaders().add("Authorization", "Basic " + token);
			}
	
		}
	}
	
}
