package com.att.idp.http.client;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.AsyncClientHttpRequestExecution;
import org.springframework.http.client.AsyncClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.concurrent.ListenableFuture;
/**
 * Adds static headers from the configuration file based on API name alias
 * 
 * @author kp7466
 *
 */
public class DefaultHeadersInterceptor implements ClientHttpRequestInterceptor, AsyncClientHttpRequestInterceptor {
	
	private static final Logger logger = LoggerFactory.getLogger(DefaultHeadersInterceptor.class);

	private Map<String, String> defaultHeaders;
	
	public DefaultHeadersInterceptor(Map<String, String> defaultHeaders) {
		super();
		this.defaultHeaders = defaultHeaders;
	}

	public Map<String, String> getDefaultHeaders() {
		return defaultHeaders;
	}

	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		logger.info("DefaultHeadersInterceptor called");		
		addDefaultHeaders(request);				
		return execution.execute(request, body);
	}

	@Override
	public ListenableFuture<ClientHttpResponse> intercept(HttpRequest request, byte[] body,
			AsyncClientHttpRequestExecution execution) throws IOException {
		logger.info("DefaultHeadersInterceptor called for AsyncRestTemplate");			
		addDefaultHeaders(request);		
		return execution.executeAsync(request, body);
	}	

	private void addDefaultHeaders(HttpRequest request) {
		HttpHeaders headers = request.getHeaders();
		
		for(Entry<String, String> entry : defaultHeaders.entrySet()) {
			headers.add(entry.getKey(), entry.getValue());
		}
	} 	
}
