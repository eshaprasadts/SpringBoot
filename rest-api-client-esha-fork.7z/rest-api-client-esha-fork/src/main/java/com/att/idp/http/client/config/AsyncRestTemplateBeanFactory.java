package com.att.idp.http.client.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.AsyncClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsAsyncClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.DefaultResponseErrorHandler;

import com.att.idp.http.client.ApiLoggingInterceptor;
import com.att.idp.http.client.DefaultHeadersInterceptor;
import com.att.idp.http.client.DynamicBasicAuthInterceptor;
import com.att.idp.logging.client.RestApiLogger;

import io.opentracing.Tracer;
import io.opentracing.contrib.spring.web.client.TracingAsyncRestTemplateInterceptor;

/**
 * Factory to create customized RestTemplate instances.
 */
@Component
public class AsyncRestTemplateBeanFactory implements FactoryBean<AsyncRestTemplate> {

	@Autowired
	Tracer tracer;

	@Autowired
	private RestClientConfig restClientProps;

	/**
	 * As a part of platform we want to recommend the usage of parameterized call to
	 * get the Rest Template Object so that, the instances returned will have API
	 * specific configurations
	 */
	@Override
	public AsyncRestTemplate getObject() throws Exception {
		return new AsyncRestTemplate();
	}

	/**
	 * Takes in the name of API for which the client is needed and sets the
	 * configurations specific to that API for each service
	 * 
	 * @param apiName
	 * @return
	 * @throws Exception
	 */
	public AsyncRestTemplate getObject(String apiName) throws Exception {

		// builder returns new instance for each additional* call,
		// Make sure to chain the calls
		if (apiName == null) {
			throw new NullPointerException("apiName");
		}	
		RestApiProperties apiProps = restClientProps.getProperties(apiName);
		
		//Sequence of Interceptor is critical due to dependency on information.
		// 1. TracingRestTemplateInterceptor
		// 2. BasicAuthInterceptor  (depends on TracingRestTemplateInterceptor)
		// 3. DefaultHeaderInterceptor (no dependency)
		// 4. ApiLoggingInterceptor	   (dependency due to info expected in logged message)
		
		List<AsyncClientHttpRequestInterceptor> interceptors = new ArrayList<>();
		
		tracingInterceptor(interceptors);
		basicAuthInterceptor(interceptors, apiProps);
		defaultHeadersInterceptor(interceptors, apiProps);
		loggingInterceptor(interceptors, apiProps);
		
		AsyncRestTemplate asyncRestTemplate = new AsyncRestTemplate();	
		asyncRestTemplate.setInterceptors(interceptors);
		// Setting the BufferingClientHttpRequestFactory in to Rest Template so that we
		// can read the request's body into memory, thus allowing for multiple
		// invocations of getBody().		
		HttpComponentsAsyncClientHttpRequestFactory httpAsyncClientFactory = new HttpComponentsAsyncClientHttpRequestFactory();
		httpAsyncClientFactory.setConnectTimeout(apiProps.getConnectTimeout());
		httpAsyncClientFactory.setReadTimeout(apiProps.getReadTimeout());

		asyncRestTemplate.setAsyncRequestFactory(httpAsyncClientFactory);
		asyncRestTemplate.setErrorHandler(new DefaultResponseErrorHandler());
	    //restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		return asyncRestTemplate;
	}
	
	private void tracingInterceptor(List<AsyncClientHttpRequestInterceptor> interceptors) {
		interceptors.add(new TracingAsyncRestTemplateInterceptor(tracer));
	}

	private void basicAuthInterceptor(List<AsyncClientHttpRequestInterceptor> interceptors, RestApiProperties apiProps) {
		if (apiProps != null && 
				("true".equalsIgnoreCase(apiProps.getBasicAuth()) || "true".equalsIgnoreCase(apiProps.getUserTypesBasicAuth()))) {			
			interceptors.add(new DynamicBasicAuthInterceptor(apiProps));
		}
	}
	
	private void defaultHeadersInterceptor(List<AsyncClientHttpRequestInterceptor> interceptors, RestApiProperties apiProps) {
		if (apiProps != null && !apiProps.getDefaultHeaders().isEmpty()) {
			interceptors.add(new DefaultHeadersInterceptor(apiProps.getDefaultHeaders()));
		}
	}

	private void loggingInterceptor(List<AsyncClientHttpRequestInterceptor> interceptors, RestApiProperties apiProps) {
		interceptors.add(new ApiLoggingInterceptor(new RestApiLogger(apiProps.getLogLevel())));
	}

	@Override
	public Class<?> getObjectType() {
		return AsyncRestTemplate.class;
	}

	@Override
	public boolean isSingleton() {
		return false;
	}

}