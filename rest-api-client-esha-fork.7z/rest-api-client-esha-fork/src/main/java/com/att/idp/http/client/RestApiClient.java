package com.att.idp.http.client;
/**
 * Marker Interface for RestApiClient
 *
 */
public interface RestApiClient {

}
