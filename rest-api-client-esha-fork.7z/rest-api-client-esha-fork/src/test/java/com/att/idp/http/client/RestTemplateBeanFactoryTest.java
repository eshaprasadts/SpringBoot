package com.att.idp.http.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import com.att.idp.http.client.config.RestTemplateBeanFactory;

@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@SpringBootTest(webEnvironment=WebEnvironment.NONE)
public class RestTemplateBeanFactoryTest {
	
	@Autowired
	RestTemplateBeanFactory factory;
	
	@Test
	public void testGetObjectByName() throws Exception {
		
		RestTemplate undefined = factory.getObject("undefined");
		assertNotNull(undefined);		
		assertEquals(3, undefined.getInterceptors().size());
		
		
		RestTemplate api1 = factory.getObject("api1");
		assertNotNull(api1);		
		assertEquals(4, api1.getInterceptors().size());		
		
		RestTemplate api2 = factory.getObject("api2");
		assertNotNull(api2);		
		assertEquals(4, api2.getInterceptors().size());
	}	

}
