package com.att.idp.http.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.att.idp.http.client.config.RestApiProperties;
import com.att.idp.http.client.config.RestClientConfig;
import com.att.idp.logging.LogLevel;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@ActiveProfiles("test")
@SpringBootTest(webEnvironment=WebEnvironment.NONE)
public class RestClientConfigTest {
	
	@Autowired
	private RestClientConfig restClientProps;
	
	@Test
	public void testDefaultConfig() {		

		//default assertions		
		RestApiProperties defaultProps = restClientProps.getProperties("default");
		assertNotNull(defaultProps);
		
		assertFalse(Boolean.parseBoolean(defaultProps.getBasicAuth()));
		assertNull(defaultProps.getUsername());
		assertNull(defaultProps.getPassword());

		assertNull(defaultProps.getUserTypesBasicAuth());
		assertNotNull(defaultProps.getUserTypes().get("registered"));
		assertNotNull(defaultProps.getUserTypes().get("registered").getUsername());
		assertNotNull(defaultProps.getUserTypes().get("registered").getPassword());
		assertEquals("defaultRegistered", defaultProps.getUserTypes().get("registered").getUsername());
		assertEquals("defaultRegistered123", defaultProps.getUserTypes().get("registered").getPassword());
		assertNotNull(defaultProps.getUserTypes().get("guest"));
		assertNotNull(defaultProps.getUserTypes().get("guest").getUsername());
		assertNotNull(defaultProps.getUserTypes().get("guest").getPassword());		
		assertEquals("defaultGuest", defaultProps.getUserTypes().get("guest").getUsername());
		assertEquals("defaultGuest123", defaultProps.getUserTypes().get("guest").getPassword());

		assertTrue(2 == defaultProps.getDefaultHeaders().size());
		assertEquals("com.att.idp.MyApp", defaultProps.getDefaultHeaders().get("X-ATT-ClientId"));
		assertEquals("application/json", defaultProps.getDefaultHeaders().get("Accept"));

		assertTrue(LogLevel.DEBUG.equals(defaultProps.getLogLevel()));
		
		assertTrue(defaultProps.getConnectTimeout() == 5000);
		assertTrue(defaultProps.getReadTimeout() == 10000);
	}
	
	@Test
	public void testUndefinedConfig() {			

		//undefined assertions		
		RestApiProperties undefinedProps = restClientProps.getProperties("undefined");
		assertNotNull(undefinedProps);

		assertFalse(Boolean.parseBoolean(undefinedProps.getBasicAuth()));
		assertNull(undefinedProps.getUsername());
		assertNull(undefinedProps.getPassword());

		assertNull(undefinedProps.getUserTypesBasicAuth());
		assertNotNull(undefinedProps.getUserTypes().get("registered"));
		assertNotNull(undefinedProps.getUserTypes().get("registered").getUsername());
		assertNotNull(undefinedProps.getUserTypes().get("registered").getPassword());		
		assertEquals("defaultRegistered", undefinedProps.getUserTypes().get("registered").getUsername());
		assertEquals("defaultRegistered123", undefinedProps.getUserTypes().get("registered").getPassword());
		assertNotNull(undefinedProps.getUserTypes().get("guest"));
		assertNotNull(undefinedProps.getUserTypes().get("guest").getUsername());
		assertNotNull(undefinedProps.getUserTypes().get("guest").getPassword());		
		assertEquals("defaultGuest", undefinedProps.getUserTypes().get("guest").getUsername());
		assertEquals("defaultGuest123", undefinedProps.getUserTypes().get("guest").getPassword());

		assertTrue(2 == undefinedProps.getDefaultHeaders().size());
		assertEquals("com.att.idp.MyApp", undefinedProps.getDefaultHeaders().get("X-ATT-ClientId"));
		assertEquals("application/json", undefinedProps.getDefaultHeaders().get("Accept"));

		assertTrue(LogLevel.DEBUG.equals(undefinedProps.getLogLevel()));
		
		assertTrue(undefinedProps.getConnectTimeout() == 5000);
		assertTrue(undefinedProps.getReadTimeout() == 10000);

	}

	
	@Test
	public void testApi1Config() {		
	
		//api1 assertions
		RestApiProperties api1Props = restClientProps.getProperties("api1");
		assertNotNull(api1Props);

		assertTrue(Boolean.parseBoolean(api1Props.getBasicAuth()));
		assertEquals("apiUser", api1Props.getUsername());
		assertEquals("apiPwd", api1Props.getPassword());

		assertEquals("false", api1Props.getUserTypesBasicAuth());
		assertNotNull(api1Props.getUserTypes().get("registered"));
		assertNotNull(api1Props.getUserTypes().get("registered").getUsername());
		assertNotNull(api1Props.getUserTypes().get("registered").getPassword());		
		assertEquals("defaultRegistered" ,api1Props.getUserTypes().get("registered").getUsername());
		assertEquals("defaultRegistered123" ,api1Props.getUserTypes().get("registered").getPassword());
		assertNotNull(api1Props.getUserTypes().get("guest"));
		assertNotNull(api1Props.getUserTypes().get("guest").getUsername());
		assertNotNull(api1Props.getUserTypes().get("guest").getPassword());		
		assertEquals("defaultGuest", api1Props.getUserTypes().get("guest").getUsername());
		assertEquals("defaultGuest123", api1Props.getUserTypes().get("guest").getPassword());

		assertTrue(3 == api1Props.getDefaultHeaders().size());
		assertEquals("com.att.idp.MyApp", api1Props.getDefaultHeaders().get("X-ATT-ClientId"));
		assertEquals("application/json", api1Props.getDefaultHeaders().get("Accept"));
		
		assertTrue(LogLevel.INFO.equals(api1Props.getLogLevel()));
		
		assertTrue(api1Props.getConnectTimeout() == 5000);
		assertTrue(api1Props.getReadTimeout() == 20000);

	}
	
	@Test
	public void testApi2Config() {		
		
		//api2 assertions
		RestApiProperties api2Props = restClientProps.getProperties("api2");
		assertNotNull(api2Props);

		assertFalse(Boolean.parseBoolean(api2Props.getBasicAuth()));
		assertNull(api2Props.getUsername());
		assertNull(api2Props.getPassword());

		assertEquals("true", api2Props.getUserTypesBasicAuth());
		assertNotNull(api2Props.getUserTypes().get("registered"));
		assertNotNull(api2Props.getUserTypes().get("registered").getUsername());
		assertNotNull(api2Props.getUserTypes().get("registered").getPassword());
		assertEquals("user1", api2Props.getUserTypes().get("registered").getUsername());
		assertEquals("password1", api2Props.getUserTypes().get("registered").getPassword());
		assertNotNull(api2Props.getUserTypes().get("guest"));
		assertNotNull(api2Props.getUserTypes().get("guest").getUsername());
		assertNotNull(api2Props.getUserTypes().get("guest").getPassword());		
		assertEquals("guest", api2Props.getUserTypes().get("guest").getUsername());
		assertEquals("guest123", api2Props.getUserTypes().get("guest").getPassword());

		assertTrue(3 == api2Props.getDefaultHeaders().size());
		assertEquals("com.att.idp.MyAppV1", api2Props.getDefaultHeaders().get("X-ATT-ClientId"));
		assertEquals("application/json", api2Props.getDefaultHeaders().get("Accept"));
		
		assertTrue(LogLevel.OFF.equals(api2Props.getLogLevel()));
	}

}
