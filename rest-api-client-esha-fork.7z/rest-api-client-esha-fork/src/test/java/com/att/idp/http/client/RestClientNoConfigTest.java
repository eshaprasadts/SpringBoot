package com.att.idp.http.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.att.idp.http.client.config.RestClientConfig;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@ActiveProfiles("noconfig")
@SpringBootTest(webEnvironment=WebEnvironment.NONE)
public class RestClientNoConfigTest {
	
	@Autowired
	private RestClientConfig restClientProps;
	
	@Test
	public void testConfig() {		
		assertNotNull(restClientProps);
		assertNull(restClientProps.getRest());	
		assertNull(restClientProps.getProperties("api1"));
	}
}
