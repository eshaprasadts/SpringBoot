package com.att.idp.http.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.opentracing.contrib.spring.web.autoconfig.RestTemplateAutoConfiguration;

@EnableAutoConfiguration(exclude={RestTemplateAutoConfiguration.class})
@SpringBootApplication
public class AppTest {

	public static void main(String[] args) {
		SpringApplication.run(AppTest.class, args);
	}

}
