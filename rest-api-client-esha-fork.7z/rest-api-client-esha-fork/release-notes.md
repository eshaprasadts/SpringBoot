This document provides the changes for each version upgrade.

# Version - 0.0.4-SNAPSHOT
Error Handling and recovery feature. Refer the link for more information: https://wiki.web.att.com/display/IDSEPA/Rest+API+Error+Handling